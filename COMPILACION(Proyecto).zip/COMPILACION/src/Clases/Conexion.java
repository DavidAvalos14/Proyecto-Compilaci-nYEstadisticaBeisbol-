/*------------------------------------------------------------------------------------------
                        Liga de Beisbol Sertoma 

                    PERIODO: VACACIONES DE VERANO 2024   

            Clase para conectar a la base de datos de Compilación
        
  Autor       : Angel David Avalos Carrillo
  Nombre      : Conexion.java
  Fecha       : JULIO/2024
  Compilador  : JDK 17 + Java NetBeans 20
  Descripción : Esta clase contiene datos para la conexión con
                la base de datos como:
                    1. Conectar
                    2. Desconectar
                Así como los métodos que se requieren para manejarla:
                    1. Alta (Equipos, Jugadores, Jornadas, JEquipos, JJugadores)
                    2. Baja (Equipos, Jugadores, Jornadas, JEquipos, JJugadores)
                    3. Modificar (Equipos, Jugadores, Jornadas, JEquipos, JJugadores)
                Y los métodos para mostrar la información de principal interés:
                    1. Mostrar la información general (Equipos, Jugadores)
                    2. Mostrar los lideres (Promedio, HomeRuns, Producidas, Picheo)
                    3. Mostra la información jornada tras jornada (Equipos, Jugadores)
                Asi como las claves de las principales tablas
                    1. Claves (Equipo, Jugador, Jornada)
                Tambien Muestra equipos y jugadores
                    1. Equipos en una categoría
                    2. Jugadores  en un Equipo
                Agregar un método para imprimir cualquier tabla en un archivo de texto
==========================================================================================*/

package Clases;

//------------------------------------------------------------------------------------------

//import Frames.LogIn;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
//import java.util.logging.Level;
//import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
//import javax.swing.table.TableModel;
import java.sql.ResultSet;
import javax.swing.JComboBox;
import javax.swing.table.TableColumnModel;

//------------------------------------------------------------------------------------------

public class Conexion {

//------------------------------------------------------------------------------------------
    
    private Connection oConexion;
    TableColumnModel modeloColumna;
    
    //------------------------------------------------------------------------------------------

    public Conexion() {
        oConexion = null;
    }

    //------------------------------------------------------------------------------------------

    // Método para conectar con la base de datos
    public Connection conectar(){
        try {
            String cadena = "jdbc:sqlserver://localhost:1433;databaseName=COMPILACIONpruebas7;integratedSecurity=false;encrypt=true;trustServerCertificate=true";
            oConexion =  DriverManager.getConnection(cadena,"sa","DAVIDavc14");  
            //JOptionPane.showMessageDialog(null,"¡Conexion exitosa!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"No se pudo conectar a la base de datos..."+ex.toString());
        }
       
        return oConexion;
    }
    
   //------------------------------------------------------------------------------------------

    //Método para desconectar
    public void desconectar() {
        try {
            oConexion.close();
            //JOptionPane.showMessageDialog(null, "DESCONEXION EXITOSA ");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERROR DE DESCONEXION " + ex.getMessage());
        }
    }
    
    //------------------------------------------------------------------------------------------

    //Usar insert para dar de alta Equipos
    public void altaEquipo(String nombre, String categoria){
        conectar();
        String query = "INSERT INTO Equipo VALUES (?,?)";
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.setString(1, nombre);
            PS.setString(2, categoria);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en el alta del Equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Update para modificar los datos de los equipos
    public void modificarEquipo(String nombre, String categoria, int id){
        conectar();
        String query = "UPDATE Equipo SET e_nombre = '" + nombre + 
                "', e_categoria = '" + categoria + 
                "' WHERE id_equipo = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar el Equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Delete para dar de baja Equipos
    public void bajaEquipo(int id){
        conectar();
        String query = "DELETE FROM Equipo WHERE id_equipo = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la baja del Equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Insert para dar de alta Jugadores
    public void altaJugador(String nombre, int equipo){
        conectar();
        String query = "INSERT INTO Jugador VALUES (?, ?)";
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.setString(1, nombre);
            PS.setInt(2, equipo);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en el alta del Jugador", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Update para modificar los datos de los Jugadores
    public void modificarJugador(String nombre, int equipo, int id){
        conectar();
        String query = "UPDATE Jugador SET j_nombre = '" + nombre + "', equipo = '"
                + equipo + "' WHERE id_jugador = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar el Jugador", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Delete para dar de baja Jugadores
    public void bajaJugador(int id){
        conectar();
        String query = "DELETE FROM Jugador WHERE id_jugador = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la baja del Jugador", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Insert para dar de alta Jornadas
    public void altaJornada(int numJornada, String fechaI, String fechaF){
        conectar();
        String query = "INSERT INTO Jornada VALUES (?, ?, ?)";
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.setInt(1, numJornada);
            PS.setString(2, fechaI);
            PS.setString(3, fechaF);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en el alta de la Jornada", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Update para modifcar la información de las Jornadas
    public void modificarJornada(int numJornada, String fechaI, String fechaF, int id){
        conectar();
        String query = "UPDATE Jornada SET numJornada = " + numJornada + ", fechaInicio = '"
                + fechaI + "', fechaFin = '" + fechaF + "' WHERE id_jornada = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar la Jornada", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Usar Delete para eliminar las Jornadas
    public void bajaJornada(int id){
        conectar();
        String query = "DELETE FROM Jornada WHERE id_jornada = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la baja de la Jornada", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Dar de alta las Jornadas de los Equipos
    public void altaJEquipo(int gano, int perdio, int anotadas, int recibidas, int jornada, int equipo){
        conectar();
        String query = "INSERT INTO JEquipo VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.setInt(1, gano);
            PS.setInt(2, perdio);
            PS.setInt(3, anotadas);
            PS.setInt(4, recibidas);
            PS.setInt(5, jornada);
            PS.setInt(6, equipo);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en el alta de la Jornada del Equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Modificar la información de las Jornadas de los Equipos
    public void modificarJEquipo(int gano, int perdio, int anotadas, int recibidas, int id){
        conectar();
        String query = "UPDATE JEquipo SET je_gano = " + gano + ", je_perdio = "
                + perdio + ", je_carrarasAnotadas = " + anotadas + 
                ", je_carrerasRecibidas = " + recibidas +  "WHERE id_jequipo = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar la Jornada del Equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Dar de baja las Jornadas de los Equipos
    public void bajaJEquipo(int id){
        conectar();
        String query = "DELETE FROM JEquipo WHERE id_jequipo = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la baja de la Jornada del Equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Dar de alta Jornadas de los Jugadores
    public void altaJJugador(double ap, double tl, double hits, int hr, int cp, int br, double il, int gano, int perdio, int jornada, int jugador){
        conectar();
        String query = "INSERT INTO JJugador VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.setDouble(1, ap);
            PS.setDouble(2, tl);
            PS.setDouble(3, hits);
            PS.setInt(4, hr);
            PS.setInt(5, cp);
            PS.setInt(6, br);
            PS.setDouble(7, il);
            PS.setInt(8, gano);
            PS.setInt(9, perdio);
            PS.setInt(10, jornada);
            PS.setInt(11, jugador);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en el alta de la Jornada del Jugador", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Modificar la información de las Jornadas de los Jugadores
    public void modificarJJugador(double ap, double tl, double hits, int hr, int cp, int br, double il, int gano, int perdio, int id){
        conectar();
        String query = "UPDATE JJugador SET jj_ap = " + ap + ", jj_tl = "
                + tl + ", jj_hits = " + hits + ", jj_hr = " + hr + 
                ", jj_cp = " + cp + ", jj_br = " + br + ", jj_il = " + il + 
                ", jj_gano = " + gano + ", jj_perdio = " + perdio + "WHERE id_jjugador = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar la Jornada del Jugador", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Dar de baja las Jornadas de los Jugadores
    public void bajaJJugador(int id){
        conectar();
        String query = "DELETE FROM JJugador WHERE id_jjugador = " + id;
        try {
            PreparedStatement PS = oConexion.prepareStatement(query);
            PS.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en la baja de la Jornada del Jugador", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar la información de los Equipos (sumatoria de las jornadas)
    public void mostrarEquipo(DefaultTableModel Tabla, String categoria){
        conectar();
        //Consultar solicitado
        //Separando por categorias 
        String query =  "SELECT " +
                            "e.e_nombre AS Equipo, " +
                            "COUNT(*) AS Juegos_Jugados, " +
                            "SUM(je.je_gano) AS Ganados, " +
                            "SUM(je.je_perdio) AS Perdidos, " +
                            "CASE " +
                                "WHEN SUM(je.je_gano) + SUM(je.je_perdio) = 0 THEN 0 " +
                                "ELSE CAST(SUM(je.je_gano) AS FLOAT) / (SUM(je.je_gano) + SUM(je.je_perdio)) " +
                            "END AS Porcentaje_De_Victorias, " +
                            "SUM(je.je_carrarasAnotadas) AS Carreras_Anotadas, " +
                            "SUM(je.je_carrerasRecibidas) AS Carreras_Recibidas, " +
                            "(SUM(je.je_carrarasAnotadas) - SUM(je.je_carrerasRecibidas)) AS Diferencial " +
                        "FROM  " +
                            "Equipo e " +
                        "JOIN " +
                            "JEquipo je ON e.id_equipo = je.equipo " +
                        "WHERE " +
                            "(e.e_categoria like '" + categoria + "') " +
                        "GROUP BY " +
                            "e.e_nombre " +
                        "ORDER BY " +
                            "Porcentaje_De_Victorias DESC, " +
                            "Diferencial DESC";
        
        try(PreparedStatement PS = oConexion.prepareStatement(query);
            ResultSet rs = PS.executeQuery()){
            
            Tabla.setRowCount(0);
            
            //Guardar los datos en cada renglón
            while(rs.next()){
                String equipo = rs.getString("Equipo");
                int juegos = rs.getInt("Juegos_Jugados");
                int ganados = rs.getInt("Ganados");
                int perdidos = rs.getInt("Perdidos");
                int diferencial = rs.getInt("Diferencial");
                int anotadas = rs.getInt("Carreras_Anotadas");
                int recibidas = rs.getInt("Carreras_Recibidas");
                float porcentaje = rs.getFloat("Porcentaje_De_Victorias");
                
                //Insertarlos en la tabla
                Tabla.addRow(new Object[]{equipo, (juegos-1), ganados, perdidos,
                                          anotadas, recibidas, porcentaje, diferencial});
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Error mostrando los Equipos", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar la información de los Jugadores (sumatoria de las jornadas)
    public void mostrarJugador(DefaultTableModel Tabla, int id){
        conectar();
        //Consulta para obtener los datos que se desean,
        //Separado por equipo, agrupado por jugador
        String query = "SELECT " +
                "Jugador.j_nombre as Jugador, " +
                "sum(jj_ap) AS Apariciones, " +
                "sum(jj_tl) AS Turnos_Legales, " +
                "sum(jj_hits) as Hits, " +
                "sum(jj_hr) as HomeRuns, " +
                "sum(jj_cp) as Carreras_Producidas, " +
                "sum(jj_br) as Robos, " +
                "CASE " +
                    "WHEN SUM(jj_tl) = 0 THEN 0 " +
                    "ELSE (sum(jj_hits) / sum(jj_tl)) " +
                "END AS Promedio, " +
                "sum(jj_il) as Innings_Lanzados, " +
                "sum(jj_gano) as Ganados, " +
                "sum(jj_perdio) as Perdidos " +
                "FROM JJugador " +
                "JOIN Jugador ON JJugador.jugador = Jugador.id_jugador " +
                "WHERE Jugador.equipo = " + id +
                "GROUP BY Jugador.j_nombre";
        
        try (PreparedStatement PS = oConexion.prepareStatement(query);
            ResultSet rs = PS.executeQuery()){
        
        Tabla.setRowCount(0);
        
        //Guardar los datos de cada renglón
            while (rs.next()) {
                    String jugador = rs.getString("Jugador");
                    double apariciones = rs.getDouble("Apariciones");
                    double turnosLegales = rs.getDouble("Turnos_Legales");
                    double hits = rs.getDouble("Hits");
                    int homeRuns = rs.getInt("HomeRuns");
                    int carrerasProducidas = rs.getInt("Carreras_Producidas");
                    double promedio = rs.getDouble("Promedio");
                    int robos = rs.getInt("Robos");
                    double inningsLanzados = rs.getDouble("Innings_Lanzados");
                    int ganados = rs.getInt("Ganados");
                    int perdidos = rs.getInt("Perdidos");

                    //Insertarlos en una tabla
                    Tabla.addRow(new Object[]{jugador, apariciones, 
                        turnosLegales, hits, homeRuns, carrerasProducidas, 
                        promedio, robos, inningsLanzados, ganados, perdidos});
            }
        }   catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error mostrando los Jugadores", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar los 10 mejores promedios de bateo
    public void lideresPromedio(JTable Tabla, String categoria) {
        DefaultTableModel CM = (DefaultTableModel)Tabla.getModel();
        TableColumnModel TCM = Tabla.getColumnModel();
        CM.setColumnIdentifiers(new Object[]{"Jugador", "Equipo", "Promedio"});
        conectar();
        //Consulta para sacar los 10 mejores promedios de bateo
        String query = "WITH RankedPlayers AS (" +
                "SELECT " +
                    "j.j_nombre AS Jugador, " +
                    "e.e_nombre AS Equipo, " +
                    "e.e_categoria AS Categoria, " +
                    "(SUM(jj.jj_hits) / SUM(jj.jj_tl)) AS Promedio, " +
                    "ROW_NUMBER() OVER (PARTITION BY e.e_categoria ORDER BY (SUM(jj.jj_hits) / SUM(jj.jj_tl)) DESC) AS Rank " +
                "FROM " +
                    "Jugador j " +
                "JOIN " +
                    "JJugador jj ON j.id_jugador = jj.jugador " +
                "JOIN " +
                    "Equipo e ON j.equipo = e.id_equipo " +
                "WHERE " +
                    "e.e_categoria = ? " +
                "GROUP BY " +
                    "j.j_nombre, " +
                    "e.e_nombre, " +
                    "e.e_categoria " +
                    ") " +
                "SELECT " +
                    "Jugador, " +
                    "Equipo, " +
                    "Categoria, " +
                    "Promedio " +
                "FROM " +
                    "RankedPlayers " +
                "WHERE " +
                    "Rank <= 10";

        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setString(1, categoria);

            try (ResultSet rs = PS.executeQuery()) {
                
                CM.setRowCount(0);
                CM.setColumnCount(3);
                
                TCM.getColumn(0).setPreferredWidth(200);
                TCM.getColumn(1).setPreferredWidth(200);
                TCM.getColumn(2).setPreferredWidth(136);
                //Guardar los datos renglón por renglón
                while (rs.next()) {
                    String jugador = rs.getString("Jugador");
                    String equipo = rs.getString("Equipo");
                    String categoriaResult = rs.getString("Categoria");
                    double promedio = rs.getDouble("Promedio");

                    //Insertarlos en la tabla
                    CM.addRow(new Object[]{jugador, equipo, promedio});
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error mostrando los lideres", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar los 10 mejores en HomeRuns
    public void lideresHomeRuns(JTable Tabla, String categoria) {
        DefaultTableModel CM = (DefaultTableModel)Tabla.getModel();
        TableColumnModel TCM = Tabla.getColumnModel();
        CM.setColumnIdentifiers(new Object[]{"Jugador", "Equipo", "HomeRuns"});
        conectar();
        String query = "WITH RankedPlayers AS (" +
                "SELECT " +
                    "j.j_nombre AS Jugador, " +
                    "e.e_nombre AS Equipo, " +
                    "e.e_categoria AS Categoria, " +
                    "SUM(jj.jj_hr) AS HomeRuns, " +
                    "ROW_NUMBER() OVER (PARTITION BY e.e_categoria ORDER BY (SUM(jj.jj_hr)) DESC) AS Rank " +
                "FROM " +
                    "Jugador j " +
                "JOIN " +
                    "JJugador jj ON j.id_jugador = jj.jugador " +
                "JOIN " +
                    "Equipo e ON j.equipo = e.id_equipo " +
                "WHERE " +
                    "e.e_categoria = ? " +
                "GROUP BY " +
                    "j.j_nombre, " +
                    "e.e_nombre, " +
                    "e.e_categoria " +
                    ") " +
                "SELECT " +
                    "Jugador, " +
                    "Equipo, " +
                    "Categoria, " +
                    "HomeRuns " +
                "FROM " +
                    "RankedPlayers " +
                "WHERE " +
                    "Rank <= 10";

        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setString(1, categoria);

            try (ResultSet rs = PS.executeQuery()) {
                
                CM.setRowCount(0);
                CM.setColumnCount(3);
                
                TCM.getColumn(0).setPreferredWidth(200);
                TCM.getColumn(1).setPreferredWidth(200);
                TCM.getColumn(2).setPreferredWidth(136);
                
                //Guardar los datos renglón por renglón
                while (rs.next()) {
                    String jugador = rs.getString("Jugador");
                    String equipo = rs.getString("Equipo");
                    String categoriaResult = rs.getString("Categoria");
                    int homeRuns = rs.getInt("HomeRuns");

                    //Agregarlos en la tabla
                    CM.addRow(new Object[]{jugador, equipo, homeRuns});
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar los Lideres", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar los 10 mejores en producidas
    public void lideresProducidas(JTable Tabla, String categoria){
        DefaultTableModel CM = (DefaultTableModel)Tabla.getModel();
        TableColumnModel TCM = Tabla.getColumnModel();
        CM.setColumnIdentifiers(new Object[]{"Jugador", "Equipo", "Producidas"});
        conectar();
        //Consulta que muestra los datos solicitados
        String query = "WITH RankedPlayers AS (" +
                    "SELECT  " +
                        "j.j_nombre AS Jugador, " +
                        "e.e_nombre AS Equipo, " +
                        "e.e_categoria AS Categoria, " +
                        "SUM(jj.jj_cp) AS Producidas, " +
                        "ROW_NUMBER() OVER (PARTITION BY e.e_categoria ORDER BY (SUM(jj.jj_cp)) DESC) AS Rank " +
                    "FROM  " +
                        "Jugador j " +
                    "JOIN  " +
                        "JJugador jj ON j.id_jugador = jj.jugador " +
                    "JOIN " +
                        "Equipo e ON j.equipo = e.id_equipo " +
                    "WHERE " +
                        "e.e_categoria = ? " +
                    "GROUP BY " +
                        "j.j_nombre, " +
                        "e.e_nombre, " +
                        "e.e_categoria " +
                        ") " +
                    "SELECT " +
                        "Jugador, " +
                        "Equipo, " +
                        "Categoria, " +
                        "Producidas " +
                    "FROM " +
                        "RankedPlayers " +
                    "WHERE " +
                        "Rank <= 10";
        
        try(PreparedStatement PS = oConexion.prepareStatement(query)){
            
            PS.setString(1, categoria);
            
            try(ResultSet RS = PS.executeQuery()){
                CM.setRowCount(0);
                CM.setColumnCount(3);
                
                TCM.getColumn(0).setPreferredWidth(200);
                TCM.getColumn(1).setPreferredWidth(200);
                TCM.getColumn(2).setPreferredWidth(136);
                
                //Guardar la información por renglón
                while(RS.next()){
                    String jugador = RS.getString("Jugador");
                    String equipo = RS.getString("Equipo");
                    String ca = RS.getString("Categoria");
                    int cp = RS.getInt("Producidas");
                    
                    //Ageragrlo a la tabla
                    CM.addRow(new Object[]{jugador, equipo, cp});
                }
            }
            
        }catch(SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar los Lideres", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar los 10 mejores en robos de base
    public void lideresRobos(JTable Tabla, String categoria){
        DefaultTableModel CM = (DefaultTableModel)Tabla.getModel();
        TableColumnModel TCM = Tabla.getColumnModel();
        CM.setColumnIdentifiers(new Object[]{"Jugador", "Equipo", "Robos"});
        conectar();
        //Consulta que muestra los datos solicitados
        String query = "WITH RankedPlayers AS (" +
                    "SELECT  " +
                        "j.j_nombre AS Jugador, " +
                        "e.e_nombre AS Equipo, " +
                        "e.e_categoria AS Categoria, " +
                        "SUM(jj.jj_br) AS Robos, " +
                        "ROW_NUMBER() OVER (PARTITION BY e.e_categoria ORDER BY (SUM(jj.jj_br)) DESC) AS Rank " +
                    "FROM  " +
                        "Jugador j " +
                    "JOIN  " +
                        "JJugador jj ON j.id_jugador = jj.jugador " +
                    "JOIN " +
                        "Equipo e ON j.equipo = e.id_equipo " +
                    "WHERE " +
                        "e.e_categoria = ? " +
                    "GROUP BY " +
                        "j.j_nombre, " +
                        "e.e_nombre, " +
                        "e.e_categoria " +
                        ") " +
                    "SELECT " +
                        "Jugador, " +
                        "Equipo, " +
                        "Categoria, " +
                        "Robos " +
                    "FROM " +
                        "RankedPlayers " +
                    "WHERE " +
                        "Rank <= 10";
        
        try(PreparedStatement PS = oConexion.prepareStatement(query)){
            
            PS.setString(1, categoria);
            
            try(ResultSet RS = PS.executeQuery()){
                CM.setRowCount(0);
                CM.setColumnCount(3);
            
                TCM.getColumn(0).setPreferredWidth(200);
                TCM.getColumn(1).setPreferredWidth(200);
                TCM.getColumn(2).setPreferredWidth(136);
                
                //Guardar la información por renglón
                while(RS.next()){
                    String jugador = RS.getString("Jugador");
                    String equipo = RS.getString("Equipo");
                    String ca = RS.getString("Categoria");
                    int br = RS.getInt("Robos");
                    
                    //Ageragrlo a la tabla
                    CM.addRow(new Object[]{jugador, equipo, br});
                }
            }
            
        }catch(SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar los Lideres", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar los 10 mejores en picheo
    public void lideresPicheo(JTable Tabla, String categoria) {
        DefaultTableModel CM = (DefaultTableModel)Tabla.getModel();
        TableColumnModel TCM = Tabla.getColumnModel();
        CM.setColumnIdentifiers(new Object[]{"Jugador", "Equipo", "GS", "PS", "PCTE"});
        conectar();
        String query = "WITH RankedPlayers AS (" +
                "SELECT " +
                    "j.j_nombre AS Jugador, " +
                    "e.e_nombre AS Equipo, " +
                    "e.e_categoria AS Categoria, " +
                    "SUM(jj.jj_gano) AS Ganados, " +
                    "SUM(jj.jj_perdio) AS Perdidos, " +
                "CASE " +
                    "WHEN SUM(jj.jj_gano) + SUM(jj.jj_perdio) = 0 THEN 0 " +
                    "ELSE CAST(SUM(jj.jj_gano) AS FLOAT) / (SUM(jj.jj_gano) + SUM(jj.jj_perdio)) " +
                "END AS Porcentaje, " +
                    "ROW_NUMBER() OVER (PARTITION BY e.e_categoria ORDER BY CAST(SUM(jj.jj_gano) AS FLOAT) / (SUM(jj.jj_gano) + SUM(jj.jj_perdio)) DESC) AS Rank " +
                "FROM " +
                    "Jugador j " +
                "JOIN " +
                    "JJugador jj ON j.id_jugador = jj.jugador " +
                "JOIN " +
                    "Equipo e ON j.equipo = e.id_equipo " +
                "WHERE " +
                    "e.e_categoria = ? " +
                "GROUP BY " +
                    "j.j_nombre, " +
                    "e.e_nombre, " +
                    "e.e_categoria " +
                    ") " +
                "SELECT " +
                    "Jugador, " +
                    "Equipo, " +
                    "Categoria, " +
                    "Ganados, " +
                    "Perdidos, " +
                    "Porcentaje " +
                "FROM " +
                    "RankedPlayers " +
                "WHERE " +
                    "Rank <= 10";

        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setString(1, categoria);

            try (ResultSet rs = PS.executeQuery()) {
                // Clear existing data
                CM.setRowCount(0);
                CM.setColumnCount(5);
                    
                while (rs.next()) {
                    String jugador = rs.getString("Jugador");
                    String equipo = rs.getString("Equipo");
                    //String categoriaResult = rs.getString("Categoria");
                    int ganados = rs.getInt("Ganados");
                    int perdidos = rs.getInt("Perdidos");
                    double porcentaje = rs.getDouble("Porcentaje");

                    // Add the row to the table model
                    TCM.getColumn(0).setPreferredWidth(200);
                    TCM.getColumn(1).setPreferredWidth(200);
                    TCM.getColumn(2).setPreferredWidth(45);
                    TCM.getColumn(3).setPreferredWidth(45);
                    TCM.getColumn(4).setPreferredWidth(46);
                    CM.addRow(new Object[]{jugador, equipo, ganados, perdidos, porcentaje});
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error mostrando los lideres", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }

    //------------------------------------------------------------------------------------------
    
    //Mostrar los juegos que han jugado los jugadores
    public void JuegosJugados(DefaultTableModel Tabla, int equipoId) {
        conectar();
        //Sacar los datos necesarios
        String query = "SELECT " +
                       "j.j_nombre AS Jugador, " +
                       "COUNT(jj.id_jjugador) AS Juegos_Jugados " +
                       "FROM " +
                       "Jugador j " +
                       "LEFT JOIN " +
                       "JJugador jj ON j.id_jugador = jj.jugador " +
                       "WHERE " +
                       "(j.equipo = ?) " +
                       "GROUP BY " +
                       "j.j_nombre";

        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setInt(1, equipoId);

            try (ResultSet rs = PS.executeQuery()) {
                
                Tabla.setRowCount(0);

                //Guardar los datos de cada renglón
                while (rs.next()) {
                    String jugador = rs.getString("Jugador");
                    int juegosJugados = rs.getInt("Juegos_Jugados");

                    //Agregarlos a la tabla
                    Tabla.addRow(new Object[]{jugador, juegosJugados});
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error con los Juegos Jugados", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar la información jornada por jornada de los Equipos
    public void mostrarJEquipo(DefaultTableModel Tabla, int equipo){
        conectar();
        String query = "SELECT " +
                    "numJornada AS Jornada, je_gano AS Ganados, je_perdio AS Perdidos, " +
                    "je_carrarasAnotadas AS Anotadas, je_carrerasRecibidas AS Recibidas " +
                "FROM " +
                    "JEquipo je " +
                "JOIN " +
                    "Jornada j ON je.jornada = j.id_jornada " +
                "WHERE " +
                    "equipo = ?";
        
        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setInt(1, equipo);

            try (ResultSet rs = PS.executeQuery()) {
                
                Tabla.setRowCount(0);

                //Guardar los datos de cada renglón
                while (rs.next()) {
                    int jornada = rs.getInt("Jornada");
                    int gano = rs.getInt("Ganados");
                    int perdio = rs.getInt("Perdidos");
                    int anotadas = rs.getInt("Anotadas");
                    int recibidas = rs.getInt("Recibidas");

                    //Agregarlos a la tabla
                    Tabla.addRow(new Object[]{jornada, gano, perdio, anotadas, recibidas});
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error con la información del equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        desconectar();
    }
    
    //------------------------------------------------------------------------------------------
    
    //Mostrar la información jornada por jornada de los Jugadores
    public void mostrarJJugador(DefaultTableModel Tabla, int jugador){
        conectar();
        String query = "SELECT " +
                    "numJornada AS Jornada, jj_ap AS Apariciones, jj_tl AS Turnos_Legales, " +
                    "jj_hits AS Hits, jj_hr AS HomeRuns, jj_cp AS Carreras_Producidas, " +
                    "jj_br AS Robos, jj_prom AS Promedio, jj_il AS Innings_Lanzados, jj_gano AS Ganados, " +
                    "jj_perdio AS Perdidos " +
                "FROM " +
                    "JJugador jj " +
                "JOIN " +
                    "Jornada j ON jj.jornada = j.id_jornada " +
                "WHERE " +
                    "jugador = ?";
        
        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setInt(1, jugador);

            try (ResultSet rs = PS.executeQuery()) {
                
                Tabla.setRowCount(0);

                //Guardar los datos de cada renglón
                while (rs.next()) {
                    int jornada = rs.getInt("Jornada");
                    double ap = rs.getDouble("Apariciones");
                    double tl = rs.getDouble("Turnos_Legales");
                    double hits = rs.getDouble("Hits");
                    int hr = rs.getInt("HomeRuns");
                    int cp = rs.getInt("Carreras_Producidas");
                    float prom = rs.getFloat("Promedio");
                    int br = rs.getInt("Robos");
                    double il = rs.getDouble("Innings_Lanzados");
                    int gano = rs.getInt("Ganados");
                    int perdio = rs.getInt("Perdidos");

                    //Agregarlos a la tabla
                    Tabla.addRow(new Object[]{jornada, ap, tl, hits, hr, cp, prom, br, il, gano, perdio});
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error con la informacion de los Jugadores", "ERROR", JOptionPane.ERROR_MESSAGE);
        }  
        desconectar();
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Mostrar información de la tabla Jornadas
    public void mostrarJornada(DefaultTableModel Tabla){
        conectar();
        String query = "SELECT * FROM Jornada";
        
        try (PreparedStatement PS = oConexion.prepareStatement(query)) {
            
            try (ResultSet rs = PS.executeQuery()) {
                
                Tabla.setRowCount(0);
                
                while(rs.next()){
                    int numJ = rs.getInt("numJornada");
                    Date fechaI = rs.getDate("fechaInicio");
                    Date fechaF = rs.getDate("fechaFin");
                    
                    Tabla.addRow(new Object[]{numJ, fechaI, fechaF});
                }
            }
            
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error con la informacion de las Jornadas", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Obtener la clave del Equipo
    public int claveEquipo(String nombre, String categoria) {
        conectar();
        int clave = -1;

        String query = "SELECT id_equipo AS Clave FROM Equipo WHERE e_nombre = ? AND e_categoria = ?";

        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setString(1, nombre);
            PS.setString(2, categoria);

            ResultSet RS = PS.executeQuery();

            if (RS.next()) {
                clave = RS.getInt("Clave");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error con la clave del Equipo", "ERROR", JOptionPane.ERROR_MESSAGE);
        }

        desconectar();
        return clave;
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Obtener la clave de un Jugador
    public int claveJugador(String nombre, int equipo){
        conectar();
        int clave = -1;

        String query = "SELECT id_jugador AS Clave FROM Jugador WHERE j_nombre = ? AND equipo = ?";

        try (PreparedStatement PS = oConexion.prepareStatement(query)) {

            PS.setString(1, nombre);
            PS.setInt(2, equipo);

            ResultSet RS = PS.executeQuery();

            if (RS.next()) {
                clave = RS.getInt("Clave");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error con la clave del jugador", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }

        desconectar();
        return clave;
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Obtener la clave de una Jornada
    public int claveJornada(int numJornada){
        conectar();
        int clave = -1;
        
        String query = "SELECT id_jornada AS Clave FROM Jornada WHERE (numJornada = ?)";
        
        try(PreparedStatement PS = oConexion.prepareStatement(query)){
            
            PS.setInt(1, numJornada);
            
            ResultSet RS = PS.executeQuery();
            
            if (RS.next()) {
                clave = RS.getInt("Clave");
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error con la clave de la Jornada", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
        
        desconectar();
        return clave;
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Obtener la clave de las Jornadas de los Equipos
    public int claveJEquipo(int jornada, int equipo){
        conectar();
        int clave = -1;
        
        String query = "SELECT id_jequipo AS Clave FROM JEquipo WHERE jornada = ? AND equipo = ?";
        
        try(PreparedStatement PS = oConexion.prepareStatement(query)){
            
            PS.setInt(1, jornada);
            PS.setInt(2, equipo);
            
            ResultSet RS = PS.executeQuery();
            
            if (RS.next()) {
                clave = RS.getInt("Clave");
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error con la clave de la Jornada del Equipo", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
        
        desconectar();
        return clave;
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Obtener la clave de las Jornadas de los Jugadores
    public int claveJJugador(int jornada, int jugador){
        conectar();
        int clave = -1;
        
        String query = "SELECT id_jjugador AS Clave FROM JJugador WHERE (jornada = ? and jugador = ?)";
        
        try(PreparedStatement PS = oConexion.prepareStatement(query)){
            
            PS.setInt(1, jornada);
            PS.setInt(2, jugador);
            
            ResultSet RS = PS.executeQuery();
            
            if (RS.next()) {
                clave = RS.getInt("Clave");
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Error con la clave de la Jornada del Jugador", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }
        
        desconectar();
        return clave;
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Consulta que retorne los equipos por categoría
    public void Equipos(JComboBox CB, String categoria){
        CB.removeAllItems();
        String query = "SELECT * FROM Equipo WHERE e_categoria = ?";
        conectar();
        
        try(PreparedStatement PS = oConexion.prepareStatement(query)){
            
            PS.setString(1, categoria);
            
            ResultSet RS = PS.executeQuery();
            
            while (RS.next()) {
                String equipo = RS.getString("e_nombre");
                CB.addItem(equipo);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error mostrando los Equipos", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }   
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Consulta que retorne los jugadores por equipo
    public void Jugadores(JComboBox CB, String equipo, String categoria){
        CB.removeAllItems();
        String query = "SELECT * FROM Jugador WHERE equipo = " + claveEquipo(equipo, categoria);
        conectar();
        
        try(PreparedStatement PS = oConexion.prepareStatement(query)){
            
            ResultSet RS = PS.executeQuery();
            
            while (RS.next()) {
                String jugador = RS.getString("j_nombre");
                CB.addItem(jugador);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error mostrando los Jugadores", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }  
    }
    
    //-----------------------------------------------------------------------------------------------------------------------
    
    //Imprimir los datos de una tabla en archivos de texto
    public void Imprimir(JTable Tabla, String archivo){
        modeloColumna = Tabla.getColumnModel();
        
        FileWriter oFW = null;
        PrintWriter oPW = null;
        
        try {
            
            //Guardar el archivo en cierta dirección
            //Colocar el nombre según que sea lo que se imprime
            oFW = new FileWriter("E:\\COMPILACION\\COMPILACION\\" + archivo + ".txt", false);
            oPW = new PrintWriter(oFW);
            
            //Recorrer los encabezados
            for(int i=0; i < Tabla.getColumnCount(); i++){
                String titulo = modeloColumna.getColumn(i).getIdentifier().toString();
                oPW.print(titulo + " | ");
            }
            
            //Brincar un renglón
            oPW.println();
            
            //Recorrer la tabla y guardar los datos en el archivo de texto
            for(int i=0; i < Tabla.getRowCount(); i++){
                for(int j=0; j < Tabla.getColumnCount(); j++){
                    String parametro = Tabla.getValueAt(i, j).toString();
                    oPW.print(parametro + " | ");
                }
                oPW.println();
            }
            
            oFW.close();
            oPW.close();
            
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error de Impresión", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //------------------------------------------------------------------------------------------
    
}
