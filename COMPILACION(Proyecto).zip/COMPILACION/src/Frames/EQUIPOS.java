/*------------------------------------------------------------------------------------------
                        Liga de Beisbol Sertoma 

                    PERIODO: VACACIONES DE VERANO 2024   

            Frame para manipular la información de Equipos
        
  Autor       : Angel David Avalos Carrillo
  Nombre      : EQUIPOS.java
  Fecha       : JULIO/2024
  Compilador  : JDK 17 + Java NetBeans 20
  Descripción : Este frame contiene los componentes necesarios para manipular la información
                de los equipos:
                    1. Dar de alta Equipos, modificarlos o darlos de baja.
                    2. Dar de alta lo que hizo el Equipo en determinada Jornada, así como   
                    modificarlo o darlo de baja.
                    3. Toda la información se resume en una tabla, dando los totales de juegos
                    jugados, ganados, perdidos, anotadas, recibidas, porcentaje y diferencial,
                    sirviendo a su vez como la tabla de posiciones.
==========================================================================================*/

package Frames;

//--------------------------------------------------------------------------------------------

import Clases.Conexion;
//import com.microsoft.sqlserver.jdbc.dataclassification.ColumnSensitivity;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

//--------------------------------------------------------------------------------------------

public class EQUIPOS extends javax.swing.JFrame {

    DefaultTableModel modelo;
    TableColumnModel modeloColumna;
    Conexion oCN = new Conexion();
    String equipo;
    String categoria;
    int jornada, gano, perdio, anotadas, recibidas;
    
    //--------------------------------------------------------------------------------------------
    
    public EQUIPOS() {
        initComponents();
        //Darle color y centrarlo
        Color color = new Color(205,205,255);
        getContentPane().setBackground(color);
        setLocationRelativeTo(null);
        //Asignar una imagen como icono
        Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Frames/Sertoma.jpg"));
        setIconImage(icon);
        //Definir distintos tamaños para cada columna
        modelo = (DefaultTableModel)jTablaEquipos.getModel();
        modeloColumna = jTablaEquipos.getColumnModel();
        modeloColumna.getColumn(0).setPreferredWidth(111);
        modeloColumna.getColumn(1).setPreferredWidth(75);
        modeloColumna.getColumn(2).setPreferredWidth(75);
        modeloColumna.getColumn(3).setPreferredWidth(75);
        modeloColumna.getColumn(4).setPreferredWidth(75);
        modeloColumna.getColumn(5).setPreferredWidth(75);
        modeloColumna.getColumn(6).setPreferredWidth(75);
        modeloColumna.getColumn(7).setPreferredWidth(75);
        // Crear un DefaultTableCellRenderer para centrar el contenido
        DefaultTableCellRenderer centrador = new DefaultTableCellRenderer();
        centrador.setHorizontalAlignment(SwingConstants.CENTER);
        // Asignar el centrador a cada columna de la tabla
        for (int i = 1; i < jTablaEquipos.getColumnCount(); i++) {
            jTablaEquipos.getColumnModel().getColumn(i).setCellRenderer(centrador);
        }
        //Conectar y mostrar los Equipos
        oCN.conectar();
        equipo = jTFNombre.getText().strip();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.mostrarEquipo(modelo, categoria);
    }

    //--------------------------------------------------------------------------------------------
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BGRecord = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabCategoria = new javax.swing.JLabel();
        jCBCategoria = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabNombre = new javax.swing.JLabel();
        jTFNombre = new javax.swing.JTextField();
        jBtnAltaEquipo = new javax.swing.JButton();
        jBtnModificarEquipo = new javax.swing.JButton();
        jBtnBajaEquipo = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabEquipo = new javax.swing.JLabel();
        jTFEquipo = new javax.swing.JTextField();
        jLabJornada = new javax.swing.JLabel();
        jSpinJornada = new javax.swing.JSpinner();
        jLabAnotadas = new javax.swing.JLabel();
        jLabRecibidas = new javax.swing.JLabel();
        jChBGano = new javax.swing.JCheckBox();
        jChBPerdio = new javax.swing.JCheckBox();
        jTFAnotadas = new javax.swing.JTextField();
        jTFRecibidas = new javax.swing.JTextField();
        jButAltaJEquipo = new javax.swing.JButton();
        jButModificarJEquipo = new javax.swing.JButton();
        jButBajaJEquipo = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablaEquipos = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuMenu = new javax.swing.JMenu();
        jMIImprimir = new javax.swing.JMenuItem();
        jMIRegresar = new javax.swing.JMenuItem();
        jMenuAyuda = new javax.swing.JMenu();
        jMISiglas = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Equipos - Sertoma");

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabCategoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabCategoria.setText("Categoría");

        jCBCategoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCBCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "5-6", "7-8", "9-10", "11-12", "13-14" }));
        jCBCategoria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jCBCategoria.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCBCategoriaItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(jLabCategoria)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(68, Short.MAX_VALUE)
                .addComponent(jCBCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabCategoria)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCBCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabNombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabNombre.setText("Nombre:");

        jTFNombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jBtnAltaEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jBtnAltaEquipo.setText("Alta");
        jBtnAltaEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAltaEquipoActionPerformed(evt);
            }
        });

        jBtnModificarEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jBtnModificarEquipo.setText("Modificar");
        jBtnModificarEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnModificarEquipoActionPerformed(evt);
            }
        });

        jBtnBajaEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jBtnBajaEquipo.setText("Baja");
        jBtnBajaEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnBajaEquipoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabNombre)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jBtnAltaEquipo)
                            .addGap(97, 97, 97)
                            .addComponent(jBtnModificarEquipo)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBtnBajaEquipo))
                        .addComponent(jTFNombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabNombre)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTFNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtnAltaEquipo)
                    .addComponent(jBtnModificarEquipo)
                    .addComponent(jBtnBajaEquipo))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabEquipo.setText("Equipo:");

        jTFEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFEquipo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabJornada.setText("Jornada:");

        jSpinJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jSpinJornada.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));
        jSpinJornada.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabAnotadas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabAnotadas.setText("Carreras Anotadas");

        jLabRecibidas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabRecibidas.setText("Carreras Recibidas");

        jChBGano.setBackground(new java.awt.Color(204, 255, 255));
        BGRecord.add(jChBGano);
        jChBGano.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jChBGano.setText("Ganó");
        jChBGano.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jChBGano.setOpaque(true);
        jChBGano.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jChBGanoItemStateChanged(evt);
            }
        });
        jChBGano.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jChBGanoStateChanged(evt);
            }
        });
        jChBGano.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jChBGanoMouseClicked(evt);
            }
        });
        jChBGano.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jChBGanoPropertyChange(evt);
            }
        });

        jChBPerdio.setBackground(new java.awt.Color(204, 255, 255));
        BGRecord.add(jChBPerdio);
        jChBPerdio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jChBPerdio.setText("Perdió");
        jChBPerdio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jChBPerdio.setOpaque(true);
        jChBPerdio.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jChBPerdioItemStateChanged(evt);
            }
        });
        jChBPerdio.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jChBPerdioStateChanged(evt);
            }
        });
        jChBPerdio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jChBPerdioMouseClicked(evt);
            }
        });
        jChBPerdio.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jChBPerdioPropertyChange(evt);
            }
        });

        jTFAnotadas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFAnotadas.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFAnotadas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFRecibidas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFRecibidas.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFRecibidas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButAltaJEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButAltaJEquipo.setText("Alta");
        jButAltaJEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButAltaJEquipoActionPerformed(evt);
            }
        });

        jButModificarJEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButModificarJEquipo.setText("Modificar");
        jButModificarJEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButModificarJEquipoActionPerformed(evt);
            }
        });

        jButBajaJEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButBajaJEquipo.setText("Baja");
        jButBajaJEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButBajaJEquipoActionPerformed(evt);
            }
        });

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));

        jTablaEquipos.setBackground(new java.awt.Color(204, 204, 204));
        jTablaEquipos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTablaEquipos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTablaEquipos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "EQUIPO", "JJ", "GS", "PS", "CA", "CR", "PCTE", "DIF"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTablaEquipos.setGridColor(new java.awt.Color(0, 0, 0));
        jTablaEquipos.setShowGrid(true);
        jTablaEquipos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablaEquiposMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablaEquipos);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabEquipo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTFEquipo)
                        .addGap(18, 18, 18)
                        .addComponent(jLabJornada)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSpinJornada, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(147, 147, 147)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButAltaJEquipo)
                        .addGap(64, 64, 64)
                        .addComponent(jButModificarJEquipo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButBajaJEquipo))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jChBGano)
                        .addGap(18, 18, 18)
                        .addComponent(jChBPerdio)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTFAnotadas)
                            .addComponent(jLabAnotadas))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTFRecibidas)
                            .addComponent(jLabRecibidas))))
                .addContainerGap(139, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabEquipo)
                    .addComponent(jTFEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabJornada)
                    .addComponent(jSpinJornada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabAnotadas)
                    .addComponent(jLabRecibidas)
                    .addComponent(jChBGano)
                    .addComponent(jChBPerdio))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFAnotadas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFRecibidas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButAltaJEquipo)
                    .addComponent(jButModificarJEquipo)
                    .addComponent(jButBajaJEquipo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 255));
        jMenuBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jMenuBar1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jMenuMenu.setText("Menú");
        jMenuMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuMenuActionPerformed(evt);
            }
        });

        jMIImprimir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMIImprimir.setText("Imprimir");
        jMIImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMIImprimirActionPerformed(evt);
            }
        });
        jMenuMenu.add(jMIImprimir);

        jMIRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMIRegresar.setText("Regresar");
        jMIRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMIRegresarActionPerformed(evt);
            }
        });
        jMenuMenu.add(jMIRegresar);

        jMenuBar1.add(jMenuMenu);

        jMenuAyuda.setText("Ayuda");

        jMISiglas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMISiglas.setText("Siglas");
        jMISiglas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMISiglasActionPerformed(evt);
            }
        });
        jMenuAyuda.add(jMISiglas);

        jMenuBar1.add(jMenuAyuda);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //--------------------------------------------------------------------------------------------
    
    private void jMIRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMIRegresarActionPerformed
        // Salir
        dispose();
    }//GEN-LAST:event_jMIRegresarActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jCBCategoriaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCBCategoriaItemStateChanged
        // Mostrar los equipos según cambie la categoría seleccionada
        equipo = jTFNombre.getText().strip();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.mostrarEquipo(modelo, categoria);
    }//GEN-LAST:event_jCBCategoriaItemStateChanged

    //--------------------------------------------------------------------------------------------
    
    private void jBtnAltaEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAltaEquipoActionPerformed
        // Dar de alta un Equipo
        equipo = jTFNombre.getText().strip();
        categoria = jCBCategoria.getSelectedItem().toString();
        jornada = Integer.parseInt(jSpinJornada.getValue().toString().strip());
        oCN.altaEquipo(equipo, categoria);
        oCN.altaJEquipo(0, 0, 0, 0, oCN.claveJornada(0), oCN.claveEquipo(equipo, categoria));
        oCN.mostrarEquipo(modelo, categoria);
    }//GEN-LAST:event_jBtnAltaEquipoActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jBtnModificarEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnModificarEquipoActionPerformed
        // Modificar dicho Equipo
        //Recibir los nuevos datos en campos de texto
        String nequipo = JOptionPane.showInputDialog("Indique el Nuevo Nombre del Equipo:");
        String ncategoria = JOptionPane.showInputDialog("Indicar la Nueva Categoría del Equipo:");
        equipo = jTFNombre.getText().strip();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.modificarEquipo(nequipo, ncategoria, oCN.claveEquipo(equipo, categoria));
        oCN.mostrarEquipo(modelo, categoria);
    }//GEN-LAST:event_jBtnModificarEquipoActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jBtnBajaEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnBajaEquipoActionPerformed
        // Dar de Baja un Equipo
        equipo = jTFNombre.getText().strip();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.bajaEquipo(oCN.claveEquipo(equipo, categoria));
        oCN.mostrarEquipo(modelo, categoria);
    }//GEN-LAST:event_jBtnBajaEquipoActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButAltaJEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButAltaJEquipoActionPerformed
        // Vaciar la información de UNA Jornada del Equipo
        try{
            //Guardar los valores en variables para posteriormente mandarlas al método
            equipo = jTFEquipo.getText().strip();
            categoria = jCBCategoria.getSelectedItem().toString();
            jornada = Integer.parseInt(jSpinJornada.getValue().toString().strip());
            if(jChBGano.isSelected() && !jChBPerdio.isSelected()){
                gano = 1;
                perdio = 0;
            }else if(!jChBGano.isSelected() && jChBPerdio.isSelected()){
                gano = 0;
                perdio = 1;
            }
            anotadas = Integer.parseInt(jTFAnotadas.getText().toString().strip());
            recibidas = Integer.parseInt(jTFRecibidas.getText().toString().strip());

            //Mandar llamar a los métodos
            oCN.altaJEquipo(gano, perdio, anotadas, recibidas, oCN.claveJornada(jornada), oCN.claveEquipo(equipo, categoria));
            oCN.mostrarEquipo(modelo, categoria);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Establezca correctamente los datos", "ERROR", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButAltaJEquipoActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButModificarJEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButModificarJEquipoActionPerformed
        // Modificar la información de tal Jornada para el Equipo
        try{
            //Guardar los valores en variables para posteriormente mandarlas al método
            equipo = jTFEquipo.getText().strip();
            categoria = jCBCategoria.getSelectedItem().toString();
            jornada = Integer.parseInt(jSpinJornada.getValue().toString().strip());
            if(jChBGano.isSelected() && !jChBPerdio.isSelected()){
                gano = 1;
                perdio = 0;
            }else if(!jChBGano.isSelected() && jChBPerdio.isSelected()){
                gano = 0;
                perdio = 1;
            }
            anotadas = Integer.parseInt(jTFAnotadas.getText());
            recibidas = Integer.parseInt(jTFRecibidas.getText());

            //Mandar llamar el método
            oCN.modificarJEquipo(gano, perdio, anotadas, recibidas, oCN.claveJEquipo(jornada, oCN.claveEquipo(equipo, categoria)));
            oCN.mostrarEquipo(modelo, categoria);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Establezca correctamente los datos", "ERROR", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButModificarJEquipoActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButBajaJEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButBajaJEquipoActionPerformed
        // Dar de Baja cierta Jornada del Equipo
        equipo = jTFEquipo.getText().strip();
        categoria = jCBCategoria.getSelectedItem().toString();
        jornada = Integer.parseInt(jSpinJornada.getValue().toString().strip());
        oCN.bajaJEquipo(oCN.claveJEquipo(oCN.claveJornada(jornada), oCN.claveEquipo(equipo, categoria)));
        oCN.mostrarEquipo(modelo, categoria);
    }//GEN-LAST:event_jButBajaJEquipoActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jTablaEquiposMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablaEquiposMouseClicked
        // Pasar el nombre del Equipo al campo de Texto con solo dar click
        if(evt.getClickCount() > 0){
            jTFNombre.setText(jTablaEquipos.getValueAt(this.jTablaEquipos.getSelectedRow(), 0).toString());
            jTFEquipo.setText(jTablaEquipos.getValueAt(this.jTablaEquipos.getSelectedRow(), 0).toString());
        }
    }//GEN-LAST:event_jTablaEquiposMouseClicked
 
    //--------------------------------------------------------------------------------------------
    
                        /*EVENTOS NO UTILIZADOS*/
    private void jChBGanoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jChBGanoStateChanged

    }//GEN-LAST:event_jChBGanoStateChanged

    private void jChBPerdioStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jChBPerdioStateChanged

    }//GEN-LAST:event_jChBPerdioStateChanged

    private void jChBGanoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jChBGanoItemStateChanged

    }//GEN-LAST:event_jChBGanoItemStateChanged

    private void jChBPerdioItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jChBPerdioItemStateChanged

    }//GEN-LAST:event_jChBPerdioItemStateChanged

    private void jChBPerdioPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jChBPerdioPropertyChange

    }//GEN-LAST:event_jChBPerdioPropertyChange

    private void jChBGanoPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jChBGanoPropertyChange

    }//GEN-LAST:event_jChBGanoPropertyChange

    //--------------------------------------------------------------------------------------------
    
    private void jChBGanoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jChBGanoMouseClicked
        // Cambiar de lugar las anotadas y recibidas según cambie si perdió o ganó
        try{
            int anotadas = Integer.parseInt(jTFAnotadas.getText());
            int recibidas = Integer.parseInt(jTFRecibidas.getText());
            jTFAnotadas.setText(Integer.toString(recibidas));
            jTFRecibidas.setText(Integer.toString(anotadas));
        } catch(NumberFormatException e) {
            
        }
    }//GEN-LAST:event_jChBGanoMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void jChBPerdioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jChBPerdioMouseClicked
        // Cambiar de lugar las anotadas y recibidas según cambie si perdió o ganó
        try{
            int anotadas = Integer.parseInt(jTFAnotadas.getText());
            int recibidas = Integer.parseInt(jTFRecibidas.getText());
            jTFAnotadas.setText(Integer.toString(recibidas));
            jTFRecibidas.setText(Integer.toString(anotadas));
        } catch(NumberFormatException e) {
            
        }
    }//GEN-LAST:event_jChBPerdioMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void jMISiglasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMISiglasActionPerformed
        // Dar a conocer que significa cada encabezado de la tabla
        JOptionPane.showMessageDialog(null, "JJ - Juegos Jugados\n"
                                        + "GS - Ganados\n"
                                        + "PS - Perdidos\n"
                                        + "CA - Carreras Anotadas\n"
                                        + "CR - Carreras Recibidas\n"
                                        + "PCTE - Porcentaje de Victorias\n"
                                        + "DIF - Diferencial de Carreras", "SIGLAS", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jMISiglasActionPerformed

    //--------------------------------------------------------------------------------------------
    
                        /*Evento no utilizado*/
    private void jMenuMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuMenuActionPerformed
        
    }//GEN-LAST:event_jMenuMenuActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jMIImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMIImprimirActionPerformed
        // Mandar la tabla a que se imprima en un archivo de texto
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.Imprimir(jTablaEquipos, "Posiciones " + categoria);
    }//GEN-LAST:event_jMIImprimirActionPerformed

    //--------------------------------------------------------------------------------------------
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EQUIPOS().setVisible(true);
            }
        });
    }

    //--------------------------------------------------------------------------------------------
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BGRecord;
    private javax.swing.JButton jBtnAltaEquipo;
    private javax.swing.JButton jBtnBajaEquipo;
    private javax.swing.JButton jBtnModificarEquipo;
    private javax.swing.JButton jButAltaJEquipo;
    private javax.swing.JButton jButBajaJEquipo;
    private javax.swing.JButton jButModificarJEquipo;
    private javax.swing.JComboBox<String> jCBCategoria;
    private javax.swing.JCheckBox jChBGano;
    private javax.swing.JCheckBox jChBPerdio;
    private javax.swing.JLabel jLabAnotadas;
    private javax.swing.JLabel jLabCategoria;
    private javax.swing.JLabel jLabEquipo;
    private javax.swing.JLabel jLabJornada;
    private javax.swing.JLabel jLabNombre;
    private javax.swing.JLabel jLabRecibidas;
    private javax.swing.JMenuItem jMIImprimir;
    private javax.swing.JMenuItem jMIRegresar;
    private javax.swing.JMenuItem jMISiglas;
    private javax.swing.JMenu jMenuAyuda;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuMenu;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSpinner jSpinJornada;
    private javax.swing.JTextField jTFAnotadas;
    private javax.swing.JTextField jTFEquipo;
    private javax.swing.JTextField jTFNombre;
    private javax.swing.JTextField jTFRecibidas;
    private javax.swing.JTable jTablaEquipos;
    // End of variables declaration//GEN-END:variables
}
