/*------------------------------------------------------------------------------------------
                        Liga de Beisbol Sertoma 

                    PERIODO: VACACIONES DE VERANO 2024   

                Frame para redirigir hacia otras ventanas
        
  Autor       : Angel David Avalos Carrillo
  Nombre      : OTROS.java
  Fecha       : JULIO/2024
  Compilador  : JDK 17 + Java NetBeans 20
  Descripción : Este frame contiene 3 botones para redirigir a ventanas menos solicitadas como:
                    1. Juegos Jugados por jugador (con vistas a play off)
                    2. Información de jornada tras jornada por Equipos y Jugadores (Verificar información)
                    3. Regresar a la ventana inicial.
==========================================================================================*/

package Frames;

//--------------------------------------------------------------------------------------------

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;

//--------------------------------------------------------------------------------------------

public class OTROS extends javax.swing.JFrame {

    //--------------------------------------------------------------------------------------------
    
    public OTROS() {
        initComponents();
        //Darle color y centrar
        Color color = new Color(205,205,255);
        getContentPane().setBackground(color);
        setLocationRelativeTo(null);
        //Asignar una imagen como icono
        Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Frames/Sertoma.jpg"));
        setIconImage(icon);
    }

    //--------------------------------------------------------------------------------------------
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        botonJuegosJugados = new javax.swing.JLabel();
        botonJorXJor = new javax.swing.JLabel();
        botonInicio = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Otros");

        botonJuegosJugados.setBackground(new java.awt.Color(204, 255, 255));
        botonJuegosJugados.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        botonJuegosJugados.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botonJuegosJugados.setText("Juegos Jugados");
        botonJuegosJugados.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonJuegosJugados.setOpaque(true);
        botonJuegosJugados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonJuegosJugadosMouseClicked(evt);
            }
        });

        botonJorXJor.setBackground(new java.awt.Color(204, 255, 255));
        botonJorXJor.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        botonJorXJor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botonJorXJor.setText("Jornada X Jornada");
        botonJorXJor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonJorXJor.setOpaque(true);
        botonJorXJor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonJorXJorMouseClicked(evt);
            }
        });

        botonInicio.setBackground(new java.awt.Color(204, 255, 255));
        botonInicio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        botonInicio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        botonInicio.setText("Inicio");
        botonInicio.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        botonInicio.setOpaque(true);
        botonInicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonInicioMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(botonJuegosJugados, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(botonJorXJor, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
            .addComponent(botonInicio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(botonJuegosJugados, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonJorXJor, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonInicio))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //--------------------------------------------------------------------------------------------
    
    private void botonInicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonInicioMouseClicked
        // Salir
        dispose();
    }//GEN-LAST:event_botonInicioMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void botonJuegosJugadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonJuegosJugadosMouseClicked
        // Ir a los Juegos Jugados de cada Jugador
        JuegosJugados jj = new JuegosJugados();
        jj.setVisible(true);
    }//GEN-LAST:event_botonJuegosJugadosMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void botonJorXJorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonJorXJorMouseClicked
        // Ir a la información Jornada tras Jornada
        JornadasX jx = new JornadasX();
        jx.setVisible(true);
    }//GEN-LAST:event_botonJorXJorMouseClicked

    //--------------------------------------------------------------------------------------------
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OTROS().setVisible(true);
            }
        });
    }

    //--------------------------------------------------------------------------------------------
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel botonInicio;
    private javax.swing.JLabel botonJorXJor;
    private javax.swing.JLabel botonJuegosJugados;
    // End of variables declaration//GEN-END:variables
}
