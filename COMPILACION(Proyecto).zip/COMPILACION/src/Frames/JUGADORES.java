/*------------------------------------------------------------------------------------------
                        Liga de Beisbol Sertoma 

                    PERIODO: VACACIONES DE VERANO 2024   

            Frame para manipular la información de los Jugadores
        
  Autor       : Angel David Avalos Carrillo
  Nombre      : JUGADORES.java
  Fecha       : JULIO/2024
  Compilador  : JDK 17 + Java NetBeans 20
  Descripción : Este frame contiene los componentes necesarios para manipular la información
                de los jugadores:
                    1. Dar de alta Jugadores, modificarlos o darlos de baja.
                    2. Dar de alta lo que hizo el Jugador en determinada Jornada, así como   
                    modificarlo o darlo de baja.
                    3. Toda la información se resume en una tabla, dando los totales de apariciones,
                    turnos legales, hits, homeruns, promedio, producidas, bases robadas, innings lanzados,
                    record de ganados y perdidos.
==========================================================================================*/

package Frames;

//--------------------------------------------------------------------------------------------

import Clases.Conexion;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

//--------------------------------------------------------------------------------------------

public class JUGADORES extends javax.swing.JFrame {

    //--------------------------------------------------------------------------------------------
    
    Conexion oCN = new Conexion();
    DefaultTableModel modelo;
    TableColumnModel modeloColumna;
    String nombre, equipo, categoria, jugador;
    int jornada, hr, cp, br, gano, perdio;
    double ap, tl, hits, il;
    
    //--------------------------------------------------------------------------------------------
    
    public JUGADORES() {
        initComponents();
        //Darle color y centrar
        Color color = new Color(205,205,255);
        getContentPane().setBackground(color);
        setLocationRelativeTo(null);
        try{
            //Asignar tamaño a cada una de las columnas
            modelo = (DefaultTableModel)jTablaJugadores.getModel();
            modeloColumna = jTablaJugadores.getColumnModel();
            modeloColumna.getColumn(0).setPreferredWidth(194);
            modeloColumna.getColumn(1).setPreferredWidth(60);
            modeloColumna.getColumn(2).setPreferredWidth(60);
            modeloColumna.getColumn(3).setPreferredWidth(60);
            modeloColumna.getColumn(4).setPreferredWidth(60);
            modeloColumna.getColumn(5).setPreferredWidth(60);
            modeloColumna.getColumn(6).setPreferredWidth(60);
            modeloColumna.getColumn(7).setPreferredWidth(60);
            modeloColumna.getColumn(8).setPreferredWidth(60);
            modeloColumna.getColumn(9).setPreferredWidth(60);
            modeloColumna.getColumn(10).setPreferredWidth(60);
            
            //Asignar una imagen como icono
            Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Frames/Sertoma.jpg"));
            setIconImage(icon);
        
            // Crear un DefaultTableCellRenderer para centrar el contenido
            DefaultTableCellRenderer centrador = new DefaultTableCellRenderer();
            centrador.setHorizontalAlignment(SwingConstants.CENTER);
        
            // Asignar el centrador a cada columna de la tabla
            for (int i = 1; i < jTablaJugadores.getColumnCount(); i++) {
                jTablaJugadores.getColumnModel().getColumn(i).setCellRenderer(centrador);
            }
        
            //Conectar y mostrar los jugadores por equipo
            oCN.conectar();
            categoria = jCBCategoria.getSelectedItem().toString();
            oCN.Equipos(jCBEquipo, categoria);
            equipo = jCBEquipo.getSelectedItem().toString();
            oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
        } catch(NullPointerException e) {
            
        }
    }

    //--------------------------------------------------------------------------------------------
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BGJugador = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabNombre = new javax.swing.JLabel();
        jTFNombre = new javax.swing.JTextField();
        jButAltaJugador = new javax.swing.JButton();
        jButModificarJugador = new javax.swing.JButton();
        jButBajaJugador = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabEquipo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabCategoria = new javax.swing.JLabel();
        jCBCategoria = new javax.swing.JComboBox<>();
        jCBEquipo = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablaJugadores = new javax.swing.JTable();
        jLabJugador = new javax.swing.JLabel();
        jTFJugador = new javax.swing.JTextField();
        jLabJornada = new javax.swing.JLabel();
        jSpinJornada = new javax.swing.JSpinner();
        jLabApariciones = new javax.swing.JLabel();
        jLabTurnosLegales = new javax.swing.JLabel();
        jLabHits = new javax.swing.JLabel();
        jLabHomeRuns = new javax.swing.JLabel();
        jLabProducidas = new javax.swing.JLabel();
        jLabRobos = new javax.swing.JLabel();
        jLabInningsLanzados = new javax.swing.JLabel();
        jChBGano = new javax.swing.JCheckBox();
        jChBPerdio = new javax.swing.JCheckBox();
        jTFApariciones = new javax.swing.JTextField();
        jTFTurnosLegales = new javax.swing.JTextField();
        jTFHits = new javax.swing.JTextField();
        jTFHomeRuns = new javax.swing.JTextField();
        jTFProducidas = new javax.swing.JTextField();
        jTFRobos = new javax.swing.JTextField();
        jTFInningsLanzados = new javax.swing.JTextField();
        jButAltaJJugador = new javax.swing.JButton();
        jButModificarJJugador = new javax.swing.JButton();
        jButBajaJJugador = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuMenu = new javax.swing.JMenu();
        jMIImprimir = new javax.swing.JMenuItem();
        jMIRegresar = new javax.swing.JMenuItem();
        jMenuAyuda = new javax.swing.JMenu();
        jMISiglas = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Jugadores - Sertoma");

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabNombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabNombre.setText("Nombre:");

        jTFNombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFNombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButAltaJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButAltaJugador.setText("Alta");
        jButAltaJugador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButAltaJugadorActionPerformed(evt);
            }
        });

        jButModificarJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButModificarJugador.setText("Modificar");
        jButModificarJugador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButModificarJugadorActionPerformed(evt);
            }
        });

        jButBajaJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButBajaJugador.setText("Baja");
        jButBajaJugador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButBajaJugadorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTFNombre)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabNombre)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButAltaJugador)
                        .addGap(122, 122, 122)
                        .addComponent(jButModificarJugador)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButBajaJugador)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabNombre)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTFNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButAltaJugador)
                    .addComponent(jButModificarJugador)
                    .addComponent(jButBajaJugador))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabEquipo.setText("Equipo:");

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabCategoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabCategoria.setText("Categoría");

        jCBCategoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCBCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "5-6", "7-8", "9-10", "11-12", "13-14" }));
        jCBCategoria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jCBCategoria.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCBCategoriaItemStateChanged(evt);
            }
        });

        jCBEquipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCBEquipo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jCBEquipo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCBEquipoItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabEquipo)
                        .addGap(75, 75, 75))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jCBEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabCategoria)
                        .addGap(35, 35, 35))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCBCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabEquipo)
                            .addComponent(jLabCategoria))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCBCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCBEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(204, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTablaJugadores.setBackground(new java.awt.Color(204, 204, 204));
        jTablaJugadores.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTablaJugadores.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTablaJugadores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "JUGADOR", "AP", "TL", "H", "HR", "CP", "AVG", "BR", "IL", "GS", "PS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTablaJugadores.setGridColor(new java.awt.Color(0, 0, 0));
        jTablaJugadores.setShowGrid(true);
        jTablaJugadores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablaJugadoresMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablaJugadores);

        jLabJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabJugador.setText("Jugador:");

        jTFJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFJugador.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabJornada.setText("Jornada:");

        jSpinJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jSpinJornada.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));
        jSpinJornada.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabApariciones.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabApariciones.setText("Apariciones");

        jLabTurnosLegales.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabTurnosLegales.setText("Turnos Legales");

        jLabHits.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabHits.setText("Hits");

        jLabHomeRuns.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabHomeRuns.setText("HomeRuns");

        jLabProducidas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabProducidas.setText("Producidas");

        jLabRobos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabRobos.setText("Robos");

        jLabInningsLanzados.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabInningsLanzados.setText("Innings Lanzados");

        jChBGano.setBackground(new java.awt.Color(204, 255, 255));
        BGJugador.add(jChBGano);
        jChBGano.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jChBGano.setText("Ganó");
        jChBGano.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jChBGano.setOpaque(true);

        jChBPerdio.setBackground(new java.awt.Color(204, 255, 255));
        BGJugador.add(jChBPerdio);
        jChBPerdio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jChBPerdio.setText("Perdió");
        jChBPerdio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jChBPerdio.setOpaque(true);

        jTFApariciones.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFApariciones.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFApariciones.setText("0");
        jTFApariciones.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFTurnosLegales.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFTurnosLegales.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFTurnosLegales.setText("0");
        jTFTurnosLegales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFHits.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFHits.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFHits.setText("0");
        jTFHits.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFHomeRuns.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFHomeRuns.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFHomeRuns.setText("0");
        jTFHomeRuns.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFProducidas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFProducidas.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFProducidas.setText("0");
        jTFProducidas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFRobos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFRobos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFRobos.setText("0");
        jTFRobos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFInningsLanzados.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFInningsLanzados.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTFInningsLanzados.setText("0");
        jTFInningsLanzados.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButAltaJJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButAltaJJugador.setText("Alta");
        jButAltaJJugador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButAltaJJugadorActionPerformed(evt);
            }
        });

        jButModificarJJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButModificarJJugador.setText("Modificar");
        jButModificarJJugador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButModificarJJugadorActionPerformed(evt);
            }
        });

        jButBajaJJugador.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButBajaJJugador.setText("Baja");
        jButBajaJJugador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButBajaJJugadorActionPerformed(evt);
            }
        });

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(jLabJugador)
                                .addGap(18, 18, 18)
                                .addComponent(jTFJugador, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabJornada)
                                .addGap(18, 18, 18)
                                .addComponent(jSpinJornada, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(73, 73, 73)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jButAltaJJugador)
                                        .addGap(215, 215, 215)
                                        .addComponent(jButModificarJJugador)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButBajaJJugador))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTFApariciones)
                                            .addComponent(jLabApariciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabTurnosLegales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTFTurnosLegales))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabHits, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTFHits, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabHomeRuns, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTFHomeRuns, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabProducidas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTFProducidas, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabRobos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTFRobos, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabInningsLanzados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTFInningsLanzados))
                                        .addGap(18, 18, 18)
                                        .addComponent(jChBGano)
                                        .addGap(18, 18, 18)
                                        .addComponent(jChBPerdio)))))
                        .addGap(0, 48, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2)
                            .addComponent(jScrollPane1))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabJugador)
                    .addComponent(jTFJugador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabJornada)
                    .addComponent(jSpinJornada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabApariciones)
                    .addComponent(jLabTurnosLegales)
                    .addComponent(jLabHits)
                    .addComponent(jLabHomeRuns)
                    .addComponent(jLabProducidas)
                    .addComponent(jLabRobos)
                    .addComponent(jLabInningsLanzados)
                    .addComponent(jChBGano)
                    .addComponent(jChBPerdio))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFApariciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFTurnosLegales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFHits, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFHomeRuns, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFProducidas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFRobos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFInningsLanzados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButAltaJJugador)
                    .addComponent(jButModificarJJugador)
                    .addComponent(jButBajaJJugador))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 364, Short.MAX_VALUE)
                .addContainerGap())
        );

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 255));
        jMenuBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jMenuBar1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jMenuMenu.setText("Menú");
        jMenuMenu.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jMIImprimir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMIImprimir.setText("Imprimir");
        jMIImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMIImprimirActionPerformed(evt);
            }
        });
        jMenuMenu.add(jMIImprimir);

        jMIRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMIRegresar.setText("Regresar");
        jMIRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMIRegresarActionPerformed(evt);
            }
        });
        jMenuMenu.add(jMIRegresar);

        jMenuBar1.add(jMenuMenu);

        jMenuAyuda.setText("Ayuda");

        jMISiglas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMISiglas.setText("Siglas");
        jMISiglas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMISiglasActionPerformed(evt);
            }
        });
        jMenuAyuda.add(jMISiglas);

        jMenuBar1.add(jMenuAyuda);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //--------------------------------------------------------------------------------------------
    
    private void jMIRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMIRegresarActionPerformed
        // Salir
        dispose();
    }//GEN-LAST:event_jMIRegresarActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButAltaJugadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButAltaJugadorActionPerformed
        // Dar de alta un Jugador
        nombre = jTFNombre.getText();
        equipo = jCBEquipo.getSelectedItem().toString();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.altaJugador(nombre, oCN.claveEquipo(equipo, categoria));
        oCN.altaJJugador(0, 0, 0, 0, 0, 0, 0, 0, 0, oCN.claveJornada(0), oCN.claveJugador(nombre, oCN.claveEquipo(equipo, categoria)));
        oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
    }//GEN-LAST:event_jButAltaJugadorActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButModificarJugadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButModificarJugadorActionPerformed
        //Mostrar mensajes con campos de texto para indicar nuevo nombre o nuevo equipo
        String nnombre = JOptionPane.showInputDialog("Indique el Nuevo Nombre del Jugador:");
        String nequipo = JOptionPane.showInputDialog("Indique el Nuevo Equipo:");
        String ncategoria = JOptionPane.showInputDialog("Indique la Categoría del Equipo Nuevo:");
        nombre = jTFNombre.getText();
        categoria = jCBCategoria.getSelectedItem().toString();
        equipo = jCBEquipo.getSelectedItem().toString();
        oCN.modificarJugador(nnombre, oCN.claveEquipo(nequipo, ncategoria), oCN.claveJugador(nombre, oCN.claveEquipo(equipo, categoria)));
        oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
    }//GEN-LAST:event_jButModificarJugadorActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButBajaJugadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButBajaJugadorActionPerformed
        // Dar de baja a determinado Jugador
        nombre = jTFNombre.getText();
        equipo = jCBEquipo.getSelectedItem().toString();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.bajaJugador(oCN.claveJugador(nombre, oCN.claveEquipo(equipo, categoria)));
        oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
    }//GEN-LAST:event_jButBajaJugadorActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButAltaJJugadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButAltaJJugadorActionPerformed
        // Dar de alta la Jornada de un Jugador
        try{
            //Guardar los datos en varables para pasarlos al método
            nombre = jTFNombre.getText();
            equipo = jCBEquipo.getSelectedItem().toString();
            categoria = jCBCategoria.getSelectedItem().toString();
            jugador = jTFJugador.getText();
            jornada = Integer.parseInt(jSpinJornada.getValue().toString());
            ap = Double.parseDouble(jTFApariciones.getText());
            tl = Double.parseDouble(jTFTurnosLegales.getText()); 
            hits = Double.parseDouble(jTFHits.getText());
            hr = Integer.parseInt(jTFHomeRuns.getText()); 
            cp = Integer.parseInt(jTFProducidas.getText()); 
            br = Integer.parseInt(jTFRobos.getText()); 
            il = Double.parseDouble(jTFInningsLanzados.getText()); 
            gano = 0;
            perdio = 0;
            if(jChBGano.isSelected() && !jChBPerdio.isSelected()){
                gano = 1;
                perdio = 0;
            } else if(!jChBGano.isSelected() && jChBPerdio.isSelected()){
                gano = 0;
                perdio = 1;
            } 

            //LLamar al método
            oCN.altaJJugador(ap, tl, hits, hr, cp, br, il, gano, perdio, oCN.claveJornada(jornada), oCN.claveJugador(nombre, oCN.claveEquipo(equipo, categoria)));
            oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Establezca correctamente los datos", "ERROR", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButAltaJJugadorActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButModificarJJugadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButModificarJJugadorActionPerformed
        // Modificar la Jornada de un Jugador
        try{
            //Guardar los datos en varables para pasarlos al método
            nombre = jTFNombre.getText();
            equipo = jCBEquipo.getSelectedItem().toString();
            categoria = jCBCategoria.getSelectedItem().toString();
            jugador = jTFJugador.getText();
            jornada = Integer.parseInt(jSpinJornada.getValue().toString());
            ap = Double.parseDouble(jTFApariciones.getText());
            tl = Double.parseDouble(jTFTurnosLegales.getText()); 
            hits = Double.parseDouble(jTFHits.getText());
            hr = Integer.parseInt(jTFHomeRuns.getText()); 
            cp = Integer.parseInt(jTFProducidas.getText()); 
            br = Integer.parseInt(jTFRobos.getText()); 
            il = Double.parseDouble(jTFInningsLanzados.getText()); 
            gano = 0;
            perdio = 0;
            if(jChBGano.isSelected() && !jChBPerdio.isSelected()){
                gano = 1;
                perdio = 0;
            } else if(!jChBGano.isSelected() && jChBPerdio.isSelected()){
                gano = 0;
                perdio = 1;
            } 
            

            //Llamar al método
            oCN.modificarJJugador(ap, tl, hits, hr, cp, br, il, gano, perdio, oCN.claveJJugador(oCN.claveJornada(jornada), oCN.claveJugador(nombre, oCN.claveEquipo(equipo, categoria))));
            oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Establezca correctamente los datos", "ERROR", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButModificarJJugadorActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButBajaJJugadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButBajaJJugadorActionPerformed
        // Dar de baja la Jornada de un Jugador
        jornada = Integer.parseInt(jSpinJornada.getValue().toString());
        nombre = jTFNombre.getText();
        equipo = jCBEquipo.getSelectedItem().toString();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.bajaJJugador(oCN.claveJJugador(oCN.claveJornada(jornada), oCN.claveJugador(nombre, oCN.claveEquipo(equipo, categoria))));
    }//GEN-LAST:event_jButBajaJJugadorActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jTablaJugadoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablaJugadoresMouseClicked
        // Mandar la información del jugador con solo dar click
        if(evt.getClickCount() > 0){
            jTFNombre.setText(jTablaJugadores.getValueAt(this.jTablaJugadores.getSelectedRow(), 0).toString());
            jTFJugador.setText(jTablaJugadores.getValueAt(this.jTablaJugadores.getSelectedRow(), 0).toString());
        }
    }//GEN-LAST:event_jTablaJugadoresMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void jCBCategoriaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCBCategoriaItemStateChanged
        // Mostrar los Equipos segun la categoria
        categoria = jCBCategoria.getSelectedItem().toString();
        equipo = jCBEquipo.getSelectedItem().toString();
        oCN.Equipos(jCBEquipo, categoria);
        oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
    }//GEN-LAST:event_jCBCategoriaItemStateChanged

    //--------------------------------------------------------------------------------------------
    
    private void jCBEquipoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCBEquipoItemStateChanged
        // Mostrar los jugadores de los equipos
        try{
            categoria = jCBCategoria.getSelectedItem().toString();
            equipo = jCBEquipo.getSelectedItem().toString();
            //oCN.Equipos(jCBEquipo, categoria);
            oCN.mostrarJugador(modelo, oCN.claveEquipo(equipo, categoria));
        } catch (NullPointerException e) {
            
        }
    }//GEN-LAST:event_jCBEquipoItemStateChanged

    //--------------------------------------------------------------------------------------------
    
    private void jMISiglasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMISiglasActionPerformed
        // Indicar la simbología de la tabla
        JOptionPane.showMessageDialog(null, "AP - Apariciones al Bat\n"
                                        + "TL - Turnos Legales\n"
                                        + "H - Hits\n"
                                        + "HR - HomeRuns\n"
                                        + "CP - Carreras Producidas\n"
                                        + "AVG - Promedio de Bateo\n"
                                        + "BR - Bases Robadas\n"
                                        + "IL - Innings Lanzados\n"
                                        + "GS - Ganados\n"
                                        + "PS - Perdidos", "SIGLAS", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jMISiglasActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jMIImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMIImprimirActionPerformed
        // Imprimir la información de los jugadores de cada equipo
        equipo = jCBEquipo.getSelectedItem().toString();
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.Imprimir(jTablaJugadores, equipo + " -- " + categoria);
    }//GEN-LAST:event_jMIImprimirActionPerformed

    //--------------------------------------------------------------------------------------------
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JUGADORES().setVisible(true);
            }
        });
    }

    //--------------------------------------------------------------------------------------------
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BGJugador;
    private javax.swing.JButton jButAltaJJugador;
    private javax.swing.JButton jButAltaJugador;
    private javax.swing.JButton jButBajaJJugador;
    private javax.swing.JButton jButBajaJugador;
    private javax.swing.JButton jButModificarJJugador;
    private javax.swing.JButton jButModificarJugador;
    private javax.swing.JComboBox<String> jCBCategoria;
    private javax.swing.JComboBox<String> jCBEquipo;
    private javax.swing.JCheckBox jChBGano;
    private javax.swing.JCheckBox jChBPerdio;
    private javax.swing.JLabel jLabApariciones;
    private javax.swing.JLabel jLabCategoria;
    private javax.swing.JLabel jLabEquipo;
    private javax.swing.JLabel jLabHits;
    private javax.swing.JLabel jLabHomeRuns;
    private javax.swing.JLabel jLabInningsLanzados;
    private javax.swing.JLabel jLabJornada;
    private javax.swing.JLabel jLabJugador;
    private javax.swing.JLabel jLabNombre;
    private javax.swing.JLabel jLabProducidas;
    private javax.swing.JLabel jLabRobos;
    private javax.swing.JLabel jLabTurnosLegales;
    private javax.swing.JMenuItem jMIImprimir;
    private javax.swing.JMenuItem jMIRegresar;
    private javax.swing.JMenuItem jMISiglas;
    private javax.swing.JMenu jMenuAyuda;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuMenu;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSpinner jSpinJornada;
    private javax.swing.JTextField jTFApariciones;
    private javax.swing.JTextField jTFHits;
    private javax.swing.JTextField jTFHomeRuns;
    private javax.swing.JTextField jTFInningsLanzados;
    private javax.swing.JTextField jTFJugador;
    private javax.swing.JTextField jTFNombre;
    private javax.swing.JTextField jTFProducidas;
    private javax.swing.JTextField jTFRobos;
    private javax.swing.JTextField jTFTurnosLegales;
    private javax.swing.JTable jTablaJugadores;
    // End of variables declaration//GEN-END:variables
}
