/*------------------------------------------------------------------------------------------
                        Liga de Beisbol Sertoma 

                    PERIODO: VACACIONES DE VERANO 2024   

            Frame para manipular la información de las Jornadas
        
  Autor       : Angel David Avalos Carrillo
  Nombre      : JORNADAS.java
  Fecha       : JULIO/2024
  Compilador  : JDK 17 + Java NetBeans 20
  Descripción : Este frame contiene los componentes necesarios para manipular la información
                de las jornadas:
                    1. Dar de alta Jornadas con su fecha de inicio y su fecha de fin, se puede modificar
                    y eliminar cierta jornada.
==========================================================================================*/

//--------------------------------------------------------------------------------------------

package Frames;

//--------------------------------------------------------------------------------------------

import Clases.Conexion;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

//--------------------------------------------------------------------------------------------

public class JORNADAS extends javax.swing.JFrame {

    //--------------------------------------------------------------------------------------------
    
    Conexion oCN = new Conexion();
    DefaultTableModel modelo;
    int jornada;
    String fechaI, fechaF;
    
    //--------------------------------------------------------------------------------------------
    
    public JORNADAS() {
        initComponents();
        //Darle color y centrar
        Color color = new Color(205,205,255);
        getContentPane().setBackground(color);
        setLocationRelativeTo(null);
        
        //Asignar una imagen como icono
        Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Frames/Sertoma.jpg"));
        setIconImage(icon);
        
        // Crear un DefaultTableCellRenderer para centrar el contenido
        DefaultTableCellRenderer centrador = new DefaultTableCellRenderer();
        centrador.setHorizontalAlignment(SwingConstants.CENTER);

        // Asignar el centrador a cada columna de la tabla
        for (int i = 0; i < jTablaJornadas.getColumnCount(); i++) {
            jTablaJornadas.getColumnModel().getColumn(i).setCellRenderer(centrador);
        }
            
        modelo = (DefaultTableModel)jTablaJornadas.getModel();
        
        //Conectar y mostrar
        oCN.conectar();
        oCN.mostrarJornada(modelo);
    }

    //--------------------------------------------------------------------------------------------
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabNumJornada = new javax.swing.JLabel();
        jLabFechaI = new javax.swing.JLabel();
        jLabFechaF = new javax.swing.JLabel();
        jSpinNumJornada = new javax.swing.JSpinner();
        jButAltaJornada = new javax.swing.JButton();
        jButModificarJornada = new javax.swing.JButton();
        jButBajaJornada = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTFFechaI = new javax.swing.JTextField();
        jTFFechaF = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablaJornadas = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuMenu = new javax.swing.JMenu();
        jMIRegresar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Jornadas - Sertoma");

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabNumJornada.setBackground(new java.awt.Color(204, 255, 255));
        jLabNumJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabNumJornada.setText("Número de Jornada");
        jLabNumJornada.setOpaque(true);

        jLabFechaI.setBackground(new java.awt.Color(204, 255, 255));
        jLabFechaI.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabFechaI.setText("Fecha de Inicio");
        jLabFechaI.setOpaque(true);

        jLabFechaF.setBackground(new java.awt.Color(204, 255, 255));
        jLabFechaF.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabFechaF.setText("Fecha de Fin");
        jLabFechaF.setOpaque(true);

        jSpinNumJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jSpinNumJornada.setModel(new javax.swing.SpinnerNumberModel(1, null, null, 1));
        jSpinNumJornada.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButAltaJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButAltaJornada.setText("Alta");
        jButAltaJornada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButAltaJornadaActionPerformed(evt);
            }
        });

        jButModificarJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButModificarJornada.setText("Modificar");
        jButModificarJornada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButModificarJornadaActionPerformed(evt);
            }
        });

        jButBajaJornada.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButBajaJornada.setText("Baja");
        jButBajaJornada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButBajaJornadaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("YYYY-MM-DD");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("YYYY-MM-DD");

        jTFFechaI.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFFechaI.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTFFechaF.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTFFechaF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jSpinNumJornada)
                        .addComponent(jLabNumJornada))
                    .addComponent(jButAltaJornada))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jButModificarJornada)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButBajaJornada))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabFechaI))
                            .addComponent(jLabel1)
                            .addComponent(jTFFechaI))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabFechaF))
                            .addComponent(jTFFechaF))
                        .addGap(10, 10, 10)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabNumJornada)
                    .addComponent(jLabFechaI)
                    .addComponent(jLabFechaF))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jSpinNumJornada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFFechaI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFFechaF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButAltaJornada)
                    .addComponent(jButModificarJornada)
                    .addComponent(jButBajaJornada))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTablaJornadas.setBackground(new java.awt.Color(204, 204, 204));
        jTablaJornadas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTablaJornadas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTablaJornadas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Jornada", "Inicio", "Fin"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTablaJornadas.setGridColor(new java.awt.Color(0, 0, 0));
        jTablaJornadas.setShowGrid(true);
        jTablaJornadas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablaJornadasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablaJornadas);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 255));
        jMenuBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jMenuMenu.setText("Menú");
        jMenuMenu.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jMIRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMIRegresar.setText("Regresar");
        jMIRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMIRegresarActionPerformed(evt);
            }
        });
        jMenuMenu.add(jMIRegresar);

        jMenuBar1.add(jMenuMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //--------------------------------------------------------------------------------------------
    
    private void jMIRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMIRegresarActionPerformed
        // Salir
        dispose();
    }//GEN-LAST:event_jMIRegresarActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButAltaJornadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButAltaJornadaActionPerformed
        // Dar de alta una Jornada
        jornada = Integer.parseInt(jSpinNumJornada.getValue().toString());
        fechaI = jTFFechaI.getText();
        fechaF = jTFFechaF.getText();
        oCN.altaJornada(jornada, fechaI, fechaF);
        oCN.mostrarJornada(modelo);
    }//GEN-LAST:event_jButAltaJornadaActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButModificarJornadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButModificarJornadaActionPerformed
        // Modificar los datos de una Jornada
        //Guardar los datos por mensajes de texto
        jornada = Integer.parseInt(jSpinNumJornada.getValue().toString());
        int njornada = Integer.parseInt(JOptionPane.showInputDialog("Indique la Nueva Jornada:"));
        String nfi = JOptionPane.showInputDialog("Indique la Nueva Fecha de Inicio:");
        String nff = JOptionPane.showInputDialog("Indique la Nueva Fecha de Fin:");
        oCN.modificarJornada(njornada, nfi, nff, oCN.claveJornada(jornada));
        oCN.mostrarJornada(modelo);
    }//GEN-LAST:event_jButModificarJornadaActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jButBajaJornadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButBajaJornadaActionPerformed
        // Dar de Baja una Jornada
        jornada = Integer.parseInt(jSpinNumJornada.getValue().toString());
        oCN.bajaJornada(oCN.claveJornada(jornada));
        oCN.mostrarJornada(modelo);
    }//GEN-LAST:event_jButBajaJornadaActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jTablaJornadasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablaJornadasMouseClicked
        // Pasar los datos a los campos con dar click
        if(evt.getClickCount() > 0){
            jSpinNumJornada.setValue(Integer.parseInt(jTablaJornadas.getValueAt(this.jTablaJornadas.getSelectedRow(), 0).toString()));
            jTFFechaI.setText(jTablaJornadas.getValueAt(this.jTablaJornadas.getSelectedRow(), 1).toString());
            jTFFechaF.setText(jTablaJornadas.getValueAt(this.jTablaJornadas.getSelectedRow(), 2).toString());
        }
    }//GEN-LAST:event_jTablaJornadasMouseClicked

    //--------------------------------------------------------------------------------------------
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JORNADAS().setVisible(true);
            }
        });
    }

    //--------------------------------------------------------------------------------------------
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButAltaJornada;
    private javax.swing.JButton jButBajaJornada;
    private javax.swing.JButton jButModificarJornada;
    private javax.swing.JLabel jLabFechaF;
    private javax.swing.JLabel jLabFechaI;
    private javax.swing.JLabel jLabNumJornada;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuItem jMIRegresar;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuMenu;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinNumJornada;
    private javax.swing.JTextField jTFFechaF;
    private javax.swing.JTextField jTFFechaI;
    private javax.swing.JTable jTablaJornadas;
    // End of variables declaration//GEN-END:variables
}
