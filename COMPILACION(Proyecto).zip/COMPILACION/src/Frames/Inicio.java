/*------------------------------------------------------------------------------------------
                        Liga de Beisbol Sertoma 

                    PERIODO: VACACIONES DE VERANO 2024   

            Frame inicial para acceder a distinta información
        
  Autor       : Angel David Avalos Carrillo
  Nombre      : Inicio.java
  Fecha       : JULIO/2024
  Compilador  : JDK 17 + Java NetBeans 20
  Descripción : Este frame contiene 5 botones que redireccionan a frames
                dedicados a la información individual de distintos tópicos:
                    1. Equipos
                    2. Jugadores
                    3. Jornadas
                    4. Lideres
                    5. Otros
==========================================================================================*/

package Frames;

//--------------------------------------------------------------------------------------------

import Clases.Conexion;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;

//--------------------------------------------------------------------------------------------

public class Inicio extends javax.swing.JFrame {

    Conexion oCN = null;
      
    //--------------------------------------------------------------------------------------------
    
    public Inicio() {
        initComponents();
        //Darle color y centrar
        Color color = new Color(205,205,255);
        getContentPane().setBackground(color);
        setLocationRelativeTo(null);
        //Asignar una imagen como icono
        Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Frames/Sertoma.jpg"));
        setIconImage(icon);
        //Crear la conexión
        oCN = new Conexion();
        oCN.conectar();
    }

    //--------------------------------------------------------------------------------------------
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BotonEquipos = new javax.swing.JLabel();
        BotonJugadores = new javax.swing.JLabel();
        BotonJornadas = new javax.swing.JLabel();
        BotonLideres = new javax.swing.JLabel();
        BotonOtros = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        MenuArchivo = new javax.swing.JMenu();
        MenuItemSalir = new javax.swing.JMenuItem();
        MenuAyuda = new javax.swing.JMenu();
        MenuItemAcercaDe = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Liga de Béisblo Infantil y Juvenil Sertoma - Torreón");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        BotonEquipos.setBackground(new java.awt.Color(204, 255, 255));
        BotonEquipos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BotonEquipos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonEquipos.setText("EQUIPOS");
        BotonEquipos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonEquipos.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BotonEquipos.setOpaque(true);
        BotonEquipos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEquiposMouseClicked(evt);
            }
        });

        BotonJugadores.setBackground(new java.awt.Color(204, 255, 255));
        BotonJugadores.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BotonJugadores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonJugadores.setText("JUGADORES");
        BotonJugadores.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonJugadores.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BotonJugadores.setOpaque(true);
        BotonJugadores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonJugadoresMouseClicked(evt);
            }
        });

        BotonJornadas.setBackground(new java.awt.Color(204, 255, 255));
        BotonJornadas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BotonJornadas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonJornadas.setText("JORNADAS");
        BotonJornadas.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonJornadas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BotonJornadas.setOpaque(true);
        BotonJornadas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonJornadasMouseClicked(evt);
            }
        });

        BotonLideres.setBackground(new java.awt.Color(204, 255, 255));
        BotonLideres.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BotonLideres.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonLideres.setText("LIDERES");
        BotonLideres.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonLideres.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BotonLideres.setOpaque(true);
        BotonLideres.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonLideresMouseClicked(evt);
            }
        });

        BotonOtros.setBackground(new java.awt.Color(204, 255, 255));
        BotonOtros.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        BotonOtros.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        BotonOtros.setText("OTROS");
        BotonOtros.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BotonOtros.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BotonOtros.setOpaque(true);
        BotonOtros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonOtrosMouseClicked(evt);
            }
        });

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 255));
        jMenuBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jMenuBar1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        MenuArchivo.setText("Archivo");

        MenuItemSalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        MenuItemSalir.setText("Salir");
        MenuItemSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuItemSalirActionPerformed(evt);
            }
        });
        MenuArchivo.add(MenuItemSalir);

        jMenuBar1.add(MenuArchivo);

        MenuAyuda.setText("Ayuda");

        MenuItemAcercaDe.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        MenuItemAcercaDe.setText("Acerca De...");
        MenuItemAcercaDe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuItemAcercaDeActionPerformed(evt);
            }
        });
        MenuAyuda.add(MenuItemAcercaDe);

        jMenuBar1.add(MenuAyuda);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BotonEquipos, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(BotonJugadores, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonJornadas, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonLideres, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BotonOtros, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BotonOtros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BotonJugadores, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BotonJornadas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BotonEquipos, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(BotonLideres, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //--------------------------------------------------------------------------------------------
    
    private void BotonEquiposMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEquiposMouseClicked
        // Acceder al Frame EQUIPOS
        EQUIPOS eq = new EQUIPOS();
        eq.setVisible(true);
    }//GEN-LAST:event_BotonEquiposMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void BotonJugadoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonJugadoresMouseClicked
        // Acceder al Frame JUGADORES
        JUGADORES jg = new JUGADORES();
        jg.setVisible(true);
    }//GEN-LAST:event_BotonJugadoresMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void BotonJornadasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonJornadasMouseClicked
        // Acceder al Frame JORNADAS
        JORNADAS jr = new JORNADAS();
        jr.setVisible(true);
    }//GEN-LAST:event_BotonJornadasMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void BotonLideresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonLideresMouseClicked
        // Acceder al Frame LIDERES
        LIDERES ld = new LIDERES();
        ld.setVisible(true);
    }//GEN-LAST:event_BotonLideresMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void BotonOtrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonOtrosMouseClicked
        // Acceder al Frame OTROS
        OTROS ot = new OTROS();
        ot.setVisible(true);
    }//GEN-LAST:event_BotonOtrosMouseClicked

    //--------------------------------------------------------------------------------------------
    
    private void MenuItemSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemSalirActionPerformed
        // Salir
        dispose();
    }//GEN-LAST:event_MenuItemSalirActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void MenuItemAcercaDeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemAcercaDeActionPerformed
        // Mostrar información sobre el programa
        JOptionPane.showMessageDialog(null, "Autor: Angel David Avalos Carrillo\n"
                            + "Liga de Béisbol Infantil y Juvenil Sertoma\n"
                            + "Versión 1.0\n"
                            + "Temporada... ", "Acerca De", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_MenuItemAcercaDeActionPerformed

    //--------------------------------------------------------------------------------------------
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    //--------------------------------------------------------------------------------------------
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BotonEquipos;
    private javax.swing.JLabel BotonJornadas;
    private javax.swing.JLabel BotonJugadores;
    private javax.swing.JLabel BotonLideres;
    private javax.swing.JLabel BotonOtros;
    private javax.swing.JMenu MenuArchivo;
    private javax.swing.JMenu MenuAyuda;
    private javax.swing.JMenuItem MenuItemAcercaDe;
    private javax.swing.JMenuItem MenuItemSalir;
    private javax.swing.JMenuBar jMenuBar1;
    // End of variables declaration//GEN-END:variables
}
