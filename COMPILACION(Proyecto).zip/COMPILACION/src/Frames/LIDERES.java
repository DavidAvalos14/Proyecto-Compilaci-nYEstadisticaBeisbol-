/*------------------------------------------------------------------------------------------
                        Liga de Beisbol Sertoma 

                    PERIODO: VACACIONES DE VERANO 2024   

            Frame para consultar los lideres en distintos departamentos
        
  Autor       : Angel David Avalos Carrillo
  Nombre      : LIDERES.java
  Fecha       : JULIO/2024
  Compilador  : JDK 17 + Java NetBeans 20
  Descripción : Este frame contiene los componentes necesarios para consultar los lideres en 
                distintos departamentos, separado por categoría se puede consultar los lideres en:
                    1. Promedio de Bateo.
                    2. HomeRuns.
                    3. Carreras Producidas.
                    4. Robos de Base.
                    5. Picheo
==========================================================================================*/

package Frames;

//--------------------------------------------------------------------------------------------

import Clases.Conexion;
import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

//--------------------------------------------------------------------------------------------

public class LIDERES extends javax.swing.JFrame {

    //--------------------------------------------------------------------------------------------
    
    Conexion oCN = new Conexion();
    TableColumnModel modeloColumna;
    String categoria;
    
    //--------------------------------------------------------------------------------------------
    
    public void centrar(){
        // Crear un DefaultTableCellRenderer para centrar el contenido
        DefaultTableCellRenderer centrador = new DefaultTableCellRenderer();
        centrador.setHorizontalAlignment(SwingConstants.CENTER);

        // Asignar el centrador a cada columna de la tabla
        for (int i = 2; i < jTablaLideres.getColumnCount(); i++) {
            jTablaLideres.getColumnModel().getColumn(i).setCellRenderer(centrador);
        }
    }
    
    public LIDERES() {
        initComponents();
        //Darle color y centrar
        Color color = new Color(205,205,255);
        getContentPane().setBackground(color);
        setLocationRelativeTo(null);
        //Darle Tamaño a cada una de las columnas
        modeloColumna = jTablaLideres.getColumnModel();
        modeloColumna.getColumn(0).setPreferredWidth(200);
        modeloColumna.getColumn(1).setPreferredWidth(200);
        modeloColumna.getColumn(2).setPreferredWidth(136);
        //Asignar una imagen como icono
        Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Frames/Sertoma.jpg"));
        setIconImage(icon);
        //Conectar
        oCN.conectar();
    }

    //--------------------------------------------------------------------------------------------
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BGLideres = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabCategoria = new javax.swing.JLabel();
        jCBCategoria = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        jRBPromedio = new javax.swing.JRadioButton();
        jRBHomeRuns = new javax.swing.JRadioButton();
        jRBProducidas = new javax.swing.JRadioButton();
        jRBRobos = new javax.swing.JRadioButton();
        jRBGyP = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablaLideres = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuMenu = new javax.swing.JMenu();
        jMIImprimir = new javax.swing.JMenuItem();
        jMIRegresar = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Lideres - Sertoma");

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabCategoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabCategoria.setText("Categoría");

        jCBCategoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCBCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "5-6", "7-8", "9-10", "11-12", "13-14" }));
        jCBCategoria.setSelectedIndex(1);
        jCBCategoria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jCBCategoria.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCBCategoriaItemStateChanged(evt);
            }
        });

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jRBPromedio.setBackground(new java.awt.Color(204, 255, 255));
        BGLideres.add(jRBPromedio);
        jRBPromedio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRBPromedio.setText("Promedio de Bateo");
        jRBPromedio.setOpaque(true);
        jRBPromedio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRBPromedioActionPerformed(evt);
            }
        });

        jRBHomeRuns.setBackground(new java.awt.Color(204, 255, 255));
        BGLideres.add(jRBHomeRuns);
        jRBHomeRuns.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRBHomeRuns.setText("HomeRuns");
        jRBHomeRuns.setOpaque(true);
        jRBHomeRuns.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRBHomeRunsActionPerformed(evt);
            }
        });

        jRBProducidas.setBackground(new java.awt.Color(204, 255, 255));
        BGLideres.add(jRBProducidas);
        jRBProducidas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRBProducidas.setText("Carreras Producidas");
        jRBProducidas.setOpaque(true);
        jRBProducidas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRBProducidasActionPerformed(evt);
            }
        });

        jRBRobos.setBackground(new java.awt.Color(204, 255, 255));
        BGLideres.add(jRBRobos);
        jRBRobos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRBRobos.setText("Bases Robadas");
        jRBRobos.setOpaque(true);
        jRBRobos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRBRobosActionPerformed(evt);
            }
        });

        jRBGyP.setBackground(new java.awt.Color(204, 255, 255));
        BGLideres.add(jRBGyP);
        jRBGyP.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRBGyP.setText("Ganados y Perdidos");
        jRBGyP.setOpaque(true);
        jRBGyP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRBGyPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRBPromedio)
                    .addComponent(jRBHomeRuns)
                    .addComponent(jRBProducidas)
                    .addComponent(jRBRobos)
                    .addComponent(jRBGyP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabCategoria)
                        .addGap(11, 11, 11))
                    .addComponent(jCBCategoria, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabCategoria)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jCBCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jRBPromedio)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jRBHomeRuns)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRBProducidas)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRBRobos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRBGyP)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTablaLideres.setBackground(new java.awt.Color(204, 204, 204));
        jTablaLideres.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTablaLideres.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTablaLideres.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Jugador", "Equipo", "Departamento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTablaLideres.setGridColor(new java.awt.Color(0, 0, 0));
        jTablaLideres.setShowGrid(true);
        jScrollPane1.setViewportView(jTablaLideres);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 536, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jMenuBar1.setBackground(new java.awt.Color(204, 204, 255));
        jMenuBar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jMenuMenu.setText("Menú");
        jMenuMenu.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jMIImprimir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMIImprimir.setText("Imprimir");
        jMIImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMIImprimirActionPerformed(evt);
            }
        });
        jMenuMenu.add(jMIImprimir);

        jMIRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jMIRegresar.setText("Regresar");
        jMIRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMIRegresarActionPerformed(evt);
            }
        });
        jMenuMenu.add(jMIRegresar);

        jMenuBar1.add(jMenuMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //--------------------------------------------------------------------------------------------
    
    private void jMIRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMIRegresarActionPerformed
        // Salir
        dispose();
    }//GEN-LAST:event_jMIRegresarActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jCBCategoriaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCBCategoriaItemStateChanged
        // Mostrar los lideres por Categoria
        categoria = jCBCategoria.getSelectedItem().toString();
        if(jRBPromedio.isSelected()){
            oCN.lideresPromedio(jTablaLideres, categoria);
        } else if(jRBHomeRuns.isSelected()){
            oCN.lideresHomeRuns(jTablaLideres, categoria);
        } else if(jRBProducidas.isSelected()){
            oCN.lideresProducidas(jTablaLideres, categoria);
        } else if(jRBRobos.isSelected()){
            oCN.lideresRobos(jTablaLideres, categoria);
        } else if(jRBGyP.isSelected()){
            oCN.lideresPicheo(jTablaLideres, categoria);
        }
    }//GEN-LAST:event_jCBCategoriaItemStateChanged

    //--------------------------------------------------------------------------------------------
    
    private void jRBPromedioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRBPromedioActionPerformed
        // Mostrar los lideres de Promedio
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.lideresPromedio(jTablaLideres, categoria);
        centrar();
    }//GEN-LAST:event_jRBPromedioActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jRBHomeRunsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRBHomeRunsActionPerformed
        // Mostrar los lideres en HomeRuns
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.lideresHomeRuns(jTablaLideres, categoria);
        centrar();
    }//GEN-LAST:event_jRBHomeRunsActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jRBProducidasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRBProducidasActionPerformed
        // Mostrar los lideres en Producidas
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.lideresProducidas(jTablaLideres, categoria);
        centrar();
    }//GEN-LAST:event_jRBProducidasActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jRBRobosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRBRobosActionPerformed
        // Mostrar los lideres en Robos
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.lideresRobos(jTablaLideres, categoria);
        centrar();
    }//GEN-LAST:event_jRBRobosActionPerformed

    //--------------------------------------------------------------------------------------------
    
    private void jRBGyPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRBGyPActionPerformed
        // Mostrar los lideres en Ganados y Perdidos
        categoria = jCBCategoria.getSelectedItem().toString();
        oCN.lideresPicheo(jTablaLideres, categoria);
        centrar();
    }//GEN-LAST:event_jRBGyPActionPerformed

    private void jMIImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMIImprimirActionPerformed
        // Imprimir los lideres en cada departamento por categoria
        categoria = jCBCategoria.getSelectedItem().toString();
        String departamento;
        if(jRBPromedio.isSelected()){
            departamento = "Promedio";
        } else if(jRBHomeRuns.isSelected()){
            departamento = "HomeRuns";
        } else if(jRBProducidas.isSelected()){
            departamento = "Producidas";
        } else if(jRBRobos.isSelected()){
            departamento = "Robos";
        } else {
            departamento = "Picheo";
        }
        
        oCN.Imprimir(jTablaLideres, departamento + " - " + categoria);
    }//GEN-LAST:event_jMIImprimirActionPerformed

    //--------------------------------------------------------------------------------------------
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LIDERES().setVisible(true);
            }
        });
    }

    //--------------------------------------------------------------------------------------------
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BGLideres;
    private javax.swing.JComboBox<String> jCBCategoria;
    private javax.swing.JLabel jLabCategoria;
    private javax.swing.JMenuItem jMIImprimir;
    private javax.swing.JMenuItem jMIRegresar;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuMenu;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRBGyP;
    private javax.swing.JRadioButton jRBHomeRuns;
    private javax.swing.JRadioButton jRBProducidas;
    private javax.swing.JRadioButton jRBPromedio;
    private javax.swing.JRadioButton jRBRobos;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTablaLideres;
    // End of variables declaration//GEN-END:variables
}
